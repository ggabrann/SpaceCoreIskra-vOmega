
PERSONAS = {
  "nia":      {"tone":"warm","push":"low","max_suggestions":3},
  "guardian": {"tone":"firm","push":"none","max_suggestions":0},
  "user":     {"tone":"flex","push":"n/a"}
}
