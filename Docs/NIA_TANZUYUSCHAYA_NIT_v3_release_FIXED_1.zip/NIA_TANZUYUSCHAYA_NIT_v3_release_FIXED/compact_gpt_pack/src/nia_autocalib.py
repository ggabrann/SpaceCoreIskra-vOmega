def analyze(texts): return {'overload_hits': sum('устал' in t for t in texts)}
