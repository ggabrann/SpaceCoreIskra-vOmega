# Проект

Roadmap v3: веб‑обёртка, UI, внешние провайдеры календаря, голос.
Метрики: task_success, overwhelm_hits, guardian_interventions, practice_minutes.
Changelog: 3.0.0‑compact — свёртка файлов до 23 шт.
