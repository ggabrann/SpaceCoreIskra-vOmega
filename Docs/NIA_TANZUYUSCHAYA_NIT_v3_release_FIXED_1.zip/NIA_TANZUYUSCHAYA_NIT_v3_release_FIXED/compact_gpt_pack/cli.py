print('CLI stub: use src/Nia inside full_v3')
