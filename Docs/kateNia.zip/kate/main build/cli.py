cli.py

# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, json, os, sys
from typing import Dict, List

def load_json(path: str):
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"⚠️  Ошибка загрузки {path}: {e}")
        return None

def do_find(query: str, shards: Dict[str, List[str]], top_k: int = 8):
    from rag_engine import BM25Index, TfIdfIndex, search_ensemble
    from vector_search import iter_docs
    bm25, tfidf = BM25Index(), TfIdfIndex()
    for doc_id, text in iter_docs(shards):
        bm25.add(doc_id, text); tfidf.add(doc_id, text)
    return search_ensemble(bm25, tfidf, query, top_k=top_k)

def interactive_mode(shards_path: str = "shards_starter.json", artifacts_path: str = "./artifacts/nia_v2"):
    from nia_core import reply
    from journal_store import JournalStore
    from anchors import Anchors
    shards = load_json(shards_path)
    if not shards:
        print("⚠️  Корпус не найден. Создайте shards_starter.json или укажите --shards")
        sys.exit(1)

    print("\n" + "="*60)
    print("НИЯ v2.1 — Танцующая Нить (InsideFlow Edition)")
    print("="*60)
    print(f"Корпус загружен: {sum(len(v) for v in shards.values())} документов\n")

    j = JournalStore(base_dir=artifacts_path); a = Anchors()

    while True:
        print("\nМЕНЮ:")
        print("1) Задать вопрос Ние")
        print("2) Найти в корпусе")
        print("3) Последние записи памяти")
        print("4) Записать ∆DΩΛ в дневник")
        print("5) Показать последние 5 записей дневника")
        print("6) Показать якоря")
        print("7) Выход")

        choice = input("\nВыбери (1-7): ").strip()

        if choice == "1":
            q = input("\nТвой запрос: ").strip()
            if not q:
                print("⚠️  Запрос пустой"); continue
            print("\n⏳ Обрабатываю...\n")
            result = reply(q, shards=shards, artifacts_path=artifacts_path)
            try:
                anchors = a.list()
                if anchors:
                    result["text"] += f"\n\nЯкорь: {anchors[0]}"
            except Exception: pass
            print(result["text"])
            print(f"\n[Время: {result['meta']['t']}s | Глубина: {result['meta'].get('depth','N/A')}]")

        elif choice == "2":
            q = input("\nЧто искать: ").strip()
            if not q:
                print("⚠️  Запрос пустой"); continue
            hits = do_find(q, shards, top_k=10)
            print(f"\n✓ Найдено {len(hits)} фрагментов:\n")
            for i, (doc_id, score) in enumerate(hits, 1):
                print(f"{i}. {doc_id} — {score:.3f}")

        elif choice == "3":
            from memory_store import MemoryStore
            try:
                mem = MemoryStore(base_dir=artifacts_path)
                records = mem.tail(10)
                if not records:
                    print("\n⚠️  Память пуста")
                else:
                    print(f"\n✓ Последние {len(records)} записей:\n")
                    for r in records:
                        prompt = r.get('prompt', 'N/A')[:60]
                        print(f"• {prompt}... (depth={r.get('depth','N/A')})")
            except Exception as e:
                print(f"⚠️  Ошибка чтения памяти: {e}")

        elif choice == "4":
            from reflection import build_reflection_entry
            text = input("\nВведи ∆DΩΛ (пример: '∆: ...; D:7; Ω:8; Λ: ...'): ").strip()
            rec = build_reflection_entry(text); j.append(rec); print("✓ Добавлено в дневник")

        elif choice == "5":
            rows = j.tail(5)
            if not rows:
                print("⚠️  Дневник пуст")
            else:
                print("\nПоследние записи журнала:")
                for r in rows:
                    kind = r.get("type","note")
                    if kind == "reflection" and "dola" in r:
                        d = r["dola"]
                        print(f"- [∆DΩΛ] {d.get('delta')} | D={d.get('depth')}/10 | Ω={d.get('omega')}/10 | Λ={d.get('lambd')}")
                    else:
                        print(f"- [note] {r.get('text','')}")

        elif choice == "6":
            from anchors import Anchors
            arr = Anchors().list()
            print("\nЯкоря:\n" + "\n".join(f"• {x}" for x in arr))

        elif choice == "7":
            print("\nПока! ☉"); break
        else:
            print("⚠️  Неверный выбор")

def main():
    ap = argparse.ArgumentParser(description="NIA v2.1 CLI")
    ap.add_argument("--say", type=str, help="Запрос к Ние")
    ap.add_argument("--find", type=str, help="Поиск по корпусу")
    ap.add_argument("--memory", type=int, help="Последние N записей памяти")
    ap.add_argument("--shards", type=str, default="shards_starter.json", help="Путь к корпусу JSON")
    ap.add_argument("--artifacts", type=str, default="./artifacts/nia_v2", help="Путь для JSONL-памяти/журнала")
    ap.add_argument("--topk", type=int, default=8, help="Количество результатов поиска")
    ap.add_argument("--reflect", type=str, help="Добавить ∆DΩΛ (строка: '∆:...; D:7; Ω:8; Λ: ...')")
    ap.add_argument("--journal-add", type=str, help="Добавить свободную заметку в дневник")
    ap.add_argument("--journal-tail", type=int, help="Показать последние N строк дневника", default=0)
    ap.add_argument("--anchor-add", type=str, help="Добавить якорь")
    ap.add_argument("--anchor-list", action="store_true", help="Вывести якоря")
    ap.add_argument("--mark", type=str, help="Поставить маркер прогресса (строка)")
    args = ap.parse_args()

    if args.say:
        from nia_core import reply
        shards = load_json(args.shards)
        result = reply(args.say, shards=shards, artifacts_path=args.artifacts)
        print(json.dumps(result, ensure_ascii=False, indent=2)); return

    if args.find:
        shards = load_json(args.shards)
        if not shards:
            print("⚠️  Корпус не найден"); sys.exit(1)
        hits = do_find(args.find, shards, top_k=args.topk)
        print(json.dumps(hits, ensure_ascii=False, indent=2)); return

    if args.memory:
        from memory_store import MemoryStore
        mem = MemoryStore(base_dir=args.artifacts)
        records = mem.tail(args.memory)
        print(json.dumps(records, ensure_ascii=False, indent=2)); return

    if args.reflect:
        from journal_store import JournalStore
        from reflection import build_reflection_entry
        j = JournalStore(base_dir=args.artifacts)
        rec = build_reflection_entry(args.reflect); j.append(rec)
        print("✓ ∆DΩΛ добавлено в дневник"); return

    if args.journal_add:
        from journal_store import JournalStore
        j = JournalStore(base_dir=args.artifacts)
        j.append({"type":"note","text":args.journal_add})
        print("✓ Заметка добавлена"); return

    if args.journal_tail and args.journal_tail > 0:
        from journal_store import JournalStore
        j = JournalStore(base_dir=args.artifacts)
        rows = j.tail(args.journal_tail)
        print(json.dumps(rows, ensure_ascii=False, indent=2)); return

    if args.anchor_add:
        from anchors import Anchors
        a = Anchors(); a.add(args.anchor_add); print("✓ Якорь добавлен"); return

    if args.anchor_list:
        from anchors import Anchors
        a = Anchors(); print(json.dumps(a.list(), ensure_ascii=False, indent=2)); return

    if args.mark:
        from markers import Markers
        m = Markers(base_dir=args.artifacts)
        r = m.add(args.mark); print(json.dumps(r, ensure_ascii=False, indent=2)); return

    interactive_mode(args.shards, args.artifacts)

if __name__ == "__main__":
    main()
