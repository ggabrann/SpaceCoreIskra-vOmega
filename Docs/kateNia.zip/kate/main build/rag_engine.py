rag_engine.py


# -*- coding: utf-8 -*-
from __future__ import annotations
import math, re, collections
from typing import Dict, List, Tuple

_TOKEN_RE = re.compile(r"[\w\-]+", re.UNICODE)
def _tok(s: str) -> List[str]:
    return [t.lower() for t in _TOKEN_RE.findall(s or "") if t.strip()]

class BM25Index:
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b; self.N = 0
        self.doc_len: Dict[str, int] = {}; self.avgdl = 0.0
        self.df: Dict[str, int] = collections.defaultdict(int)
        self.tf: Dict[str, Dict[str, int]] = collections.defaultdict(lambda: collections.defaultdict(int))

    def add(self, doc_id: str, text: str):
        tokens = _tok(text); self.N += 1; self.doc_len[doc_id] = len(tokens)
        for term, cnt in collections.Counter(tokens).items():
            self.tf[term][doc_id] = cnt; self.df[term] += 1
        self.avgdl = (sum(self.doc_len.values()) / float(self.N)) if self.N else 0.0

    def idf(self, term: str) -> float:
        df = self.df.get(term, 0)
        return math.log(1 + (self.N - df + 0.5) / (df + 0.5)) if self.N else 0.0

    def search(self, query: str, top_k: int = 8) -> List[Tuple[str, float]]:
        q_terms = _tok(query); scores: Dict[str, float] = collections.defaultdict(float)
        for term in q_terms:
            postings = self.tf.get(term, {}); idf = self.idf(term)
            for doc_id, f in postings.items():
                dl = self.doc_len.get(doc_id, 1)
                denom = f + self.k1 * (1 - self.b + self.b * dl / (self.avgdl or 1.0))
                scores[doc_id] += idf * (f * (self.k1 + 1)) / (denom or 1.0)
        return sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]

class TfIdfIndex:
    def __init__(self):
        self.N = 0; self.df: Dict[str, int] = collections.defaultdict(int)
        self.tf: Dict[str, Dict[str, int]] = collections.defaultdict(lambda: collections.defaultdict(int))
        self.doc_len: Dict[str, int] = {}

    def add(self, doc_id: str, text: str):
        tokens = _tok(text); self.N += 1; self.doc_len[doc_id] = len(tokens)
        for term, cnt in collections.Counter(tokens).items():
            self.tf[term][doc_id] = cnt; self.df[term] += 1

    def idf(self, term: str) -> float:
        df = self.df.get(term, 0)
        return math.log((self.N + 1) / (df + 1)) + 1.0 if self.N else 0.0

    def search(self, query: str, top_k: int = 8) -> List[Tuple[str, float]]:
        q_terms = _tok(query); scores: Dict[str, float] = collections.defaultdict(float)
        for term in q_terms:
            idf = self.idf(term); postings = self.tf.get(term, {})
            for doc_id, f in postings.items():
                dl = self.doc_len.get(doc_id, 1); tf = f / float(max(dl, 1))
                scores[doc_id] += tf * idf
        return sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]

def _minmax_norm(items: List[Tuple[str, float]]):
    if not items: return {}
    vals = [v for _, v in items]; mn, mx = min(vals), max(vals)
    if mx - mn < 1e-9: return {k: 1.0 for k, _ in items}
    return {k: (v - mn) / (mx - mn) for k, v in items}

def search_ensemble(bm25: BM25Index, tfidf: TfIdfIndex, query: str, top_k: int = 8):
    bm = bm25.search(query, top_k=top_k*2); tf = tfidf.search(query, top_k=top_k*2)
    bm_n = _minmax_norm(bm); tf_n = _minmax_norm(tf)
    keys = set(bm_n) | set(tf_n)
    scores = [(k, 0.5*bm_n.get(k,0.0) + 0.5*tf_n.get(k,0.0)) for k in keys]
    scores.sort(key=lambda x: x[1], reverse=True)
    return scores[:top_k]
