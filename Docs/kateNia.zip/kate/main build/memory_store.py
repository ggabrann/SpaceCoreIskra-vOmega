memory_store.py

# -*- coding: utf-8 -*-
from __future__ import annotations
import os, json, time
from typing import Dict, Any, List

class MemoryStore:
    def __init__(self, base_dir: str = "./artifacts/nia_v2", name: str = "memory.jsonl"):
        self.base_dir = base_dir
        os.makedirs(self.base_dir, exist_ok=True)
        self.path = os.path.join(self.base_dir, name)

    def append(self, obj: Dict[str, Any]) -> None:
        rec = dict(obj or {}); rec.setdefault("ts", time.time())
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def tail(self, n: int = 20) -> List[Dict[str, Any]]:
        if not os.path.exists(self.path): return []
        with open(self.path, "r", encoding="utf-8") as f:
            lines = f.readlines()[-n:]
        out = []
        for ln in lines:
            try: out.append(json.loads(ln))
            except Exception: pass
        return out
