# -*- coding: utf-8 -*-
"""
inside_flow_knowledge.py — Исчерпывающая база знаний Inside Flow

Включает:
- Философию и историю метода
- Технику и биомеханику
- Музыкальность и ритм
- Психологию практики
- Преподавание
- Работу с травмой
- Сообщество
"""

INSIDE_FLOW_KNOWLEDGE = {
    "philosophy": {
        "origin": "Inside Flow создан Young Ho Kim, объединяет виньяса-йогу с современной музыкой",
        "essence": "Движение как история, музыка как проводник, дыхание как нить",
        "core_motto": "All you need is Inside",
        "principles": [
            "Не поза, а состояние — каждая асана это момент истории",
            "Музыка ведёт — не фон, а драматургия класса",
            "Дыхание связывает — мост между телом и сознанием",
            "Переходы важнее поз — танец в движении между",
            "Несовершенство прекрасно — ошибка это часть живого потока",
            "Практика для всех — нет идеального тела, есть честное присутствие"
        ],
        "vs_traditional_yoga": {
            "vinyasa": "Виньяса — свободный поток, Inside Flow — хореография под конкретный трек",
            "hatha": "Хатха — статика и удержание, Inside Flow — непрерывное движение",
            "ashtanga": "Аштанга — фиксированная последовательность, Inside Flow — уникальная связка под каждую песню"
        }
    },
    
    "technique": {
        "structure": {
            "count": "4×8 — четыре цикла по восемь счётов",
            "phases": [
                "Warm-up (разминка) — 1-2 цикла, простые движения",
                "Building (построение) — 2-3 цикла, усложнение связки",
                "Peak (кульминация) — 1-2 цикла, самая сложная часть",
                "Cool-down (закрытие) — 1-2 цикла, успокоение"
            ],
            "timing": "Класс 60-90 минут, сама связка 4-6 минут (длина трека)"
        },
        
        "breath": {
            "rule": "1 движение = 1 дыхание",
            "inhale_actions": ["подъём рук", "раскрытие грудной клетки", "прогиб", "выпрямление"],
            "exhale_actions": ["опускание", "складывание", "скрутка", "наклон"],
            "holds": "Удержания только на кульминации, не более 2-3 счётов",
            "exceptions": "В балансах дыхание свободное, не привязано к счёту"
        },
        
        "biomechanics": {
            "spine": [
                "Волна позвоночника — кошка-корова как основа разминки",
                "Нейтральная позиция — таз подкручен, поясница защищена",
                "Скрутки через выдох — никогда через задержку"
            ],
            "joints": [
                "Мягкие колени ВСЕГДА — даже в прямых ногах микросгиб",
                "Плечи от ушей — постоянный контроль",
                "Запястья — ладонь на полу, пальцы широко, вес на основание",
                "Шея свободна — взгляд (дришти) ведёт, но без напряжения"
            ],
            "bandhas": [
                "Мула-бандха — подтягивание тазового дна, опора для поясницы",
                "Уддияна-бандха — лёгкое втягивание живота на выдохе",
                "Джаландхара-бандха — не используется в Inside Flow (шея свободна)"
            ]
        },
        
        "asanas_vocabulary": {
            "standing": ["Тадасана", "Уткатасана", "Вирабхадрасана I/II/III", "Триконасана", "Паршваконасана"],
            "balances": ["Врикшасана", "Гарудасана", "Натараджасана", "Ардха Чандрасана"],
            "floor": ["Адхо Мукха Шванасана", "Планка", "Чатуранга", "Кобра/Собака мордой вверх"],
            "inversions": ["Стойка на плечах (редко)", "Випарита Карани (ноги вверх)"],
            "hip_openers": ["Голубь", "Ящерица", "Лягушка", "Баддха Конасана"],
            "transitions": ["Виньяса (планка-чатуранга-кобра-собака)", "Прыжок вперёд/назад", "Step-through"]
        }
    },
    
    "musicality": {
        "bpm_range": "80-120 BPM идеально, 60-80 медитативно, 120+ энергично",
        "track_structure": {
            "intro": "8-16 счётов, простые движения, заземление",
            "verse_1": "Построение связки, знакомство с движениями",
            "chorus": "Повторение связки, закрепление",
            "verse_2": "Усложнение или вариация",
            "chorus_2": "Полная связка с уверенностью",
            "bridge": "Пик интенсивности или неожиданное изменение",
            "final_chorus": "Кульминация, все силы",
            "outro": "Закрытие, возврат в тело, дыхание"
        },
        
        "genres": {
            "preferred": ["Acoustic pop", "Indie folk", "Singer-songwriter", "Cinematic"],
            "works": ["Dermot Kennedy", "Dean Lewis", "Stephen Stanley", "RY X", "Ben Howard"],
            "avoid": ["Heavy metal", "Rap с резким битом", "Техно без мелодии"]
        },
        
        "lyrics_and_meaning": "Лирика должна резонировать с интенцией класса — преодоление, любовь, отпускание, возвращение домой",
        
        "dynamics": {
            "contrast": "Мягкость ↔ Сила — эмоциональная дуга",
            "build": "Постепенное нарастание от тихого к громкому",
            "drop": "Момент тишины перед кульминацией",
            "resolution": "Возврат к спокойствию в конце"
        }
    },
    
    "psychology": {
        "fear_of_visibility": {
            "camera": "Камера фиксирует = делает уязвимость видимой",
            "solution": "Начать с записи только для себя, без публикации",
            "reframe": "Камера — не судья, а свидетель твоего пути"
        },
        
        "perfectionism": {
            "trap": "Ожидание идеала блокирует начало",
            "truth": "Идеальной связки не существует, даже у создателей метода",
            "practice": "Каждая ошибка = уникальный момент, который не повторится"
        },
        
        "comparison": {
            "poison": "Сравнение с другими убивает радость практики",
            "antidote": "Каждое тело уникально — твоя история, твой ритм",
            "focus": "Сравнивай себя только с собой вчерашней"
        },
        
        "burnout": {
            "signs": ["Практика стала долгом", "Не чувствую радости", "Тело болит от перегрузки", "Избегаю коврика"],
            "causes": "Даю больше, чем получаю; забыла практиковать для себя",
            "recovery": "Вернуться к простым 8-12 минутам, дышать, двигаться без цели"
        },
        
        "trauma_sensitive": {
            "principles": [
                "Выбор всегда у практикующего — никакого принуждения",
                "Предупреждать о сложных позах заранее",
                "Касания только с явного согласия",
                "Избегать триггерных тем в интенциях (насилие, потеря контроля)",
                "Давать альтернативы для каждой позы"
            ],
            "language": "Не 'правильно/неправильно', а 'вариант А или вариант Б'",
            "safe_space": "Класс — пространство, где можно остановиться в любой момент без объяснений"
        }
    },
    
    "teaching": {
        "preparation": {
            "choose_track": "Слушай 5-10 раз, чувствуй динамику и эмоцию",
            "build_sequence": "Начни с кульминации (пик трека), работай назад",
            "timing": "Каждое движение = 1 счёт, проверяй с секундомером",
            "transitions": "Самое сложное — плавные переходы между асанами",
            "practice_alone": "Пройди связку 10+ раз сам, тело запомнит"
        },
        
        "class_structure": {
            "intro_5min": "Приветствие, интенция, дыхание (3-5 циклов)",
            "warmup_10min": "Мягкие движения, волна позвоночника, кошка-корова, приветствие солнцу",
            "teach_sequence_20min": "По частям: разбор движений без музыки, потом с музыкой",
            "full_flow_15min": "3-4 полных прохода связки под трек",
            "cool_down_5min": "Растяжка, скрутки лёжа, шавасана",
            "closing_5min": "Благодарность телу, интеграция"
        },
        
        "cueing": {
            "types": ["Визуальный (показываю)", "Вербальный (говорю)", "Тактильный (касаюсь с согласия)"],
            "priority": "Визуальный > Вербальный > Тактильный",
            "language": ["Короткие команды", "Дыхательные подсказки", "Образы (как будто...)", "Не технические термины"],
            "timing": "Куй на 1-2 счёта ДО движения, тело должно успеть"
        },
        
        "mistakes_handling": {
            "own_mistakes": "Смейся, дыши, продолжай — показываешь, что ошибка это норма",
            "student_mistakes": "Никогда не указывай публично, предложи вариант для всех",
            "confusion": "Если группа не может следовать — упрости связку прямо сейчас"
        },
        
        "energy_management": {
            "mirror": "Отражай энергию группы, не навязывай свою",
            "pacing": "Если видишь усталость — даёшь детскую позу и дыхание",
            "ending": "Всегда заканчивай на 5 минут раньше, чем планировала — запас для шавасаны"
        }
    },
    
    "community": {
        "teachers": {
            "young_ho_kim": "Создатель Inside Flow, Корея/Германия",
            "julia_vlasova": "@jv_julia_vlasova — методист, обучение преподавателей",
            "emi": "@emi_instayoga — наставник Кати, лидер команды, сцена",
            "network": "Inside Flow Russia, Inside Flow International"
        },
        
        "kate_path": {
            "start": "2.5 года назад, первая онлайн-практика с Эми",
            "milestone_1": "Через 6 месяцев — Teacher's курс",
            "milestone_2": "Номинант Junior-преподавателя",
            "now": "Ведёт классы в EMISPACE, работает над онлайн-уверенностью",
            "strengths": ["Забота", "Ощущение ритма группы", "Мягкое ведение"],
            "challenges": ["Страх камеры/онлайн", "Перфекционизм", "Выгорание от избыточной отдачи"]
        },
        
        "emispace": {
            "philosophy": "Пространство, где каждая эмоция правильная",
            "format": ["Онлайн-классы", "Офлайн-встречи", "Сцена 100+ участников"],
            "values": ["Поддержка", "Честность", "Рост без давления", "Комьюнити > Индивидуальность"]
        }
    },
    
    "practical_tips": {
        "home_practice": {
            "minimum": "8 минут — дыхание + 3 асаны + дыхание",
            "optimal": "20-30 минут — разминка + связка + растяжка",
            "realistic": "Лучше 8 минут каждый день, чем 90 минут раз в неделю"
        },
        
        "equipment": {
            "essential": "Коврик (не скользкий)",
            "nice_to_have": ["Блоки (2 шт)", "Ремень", "Болстер", "Плед"],
            "music": "Колонка или хорошие наушники (не затычки — нужен бас)"
        },
        
        "safety": {
            "red_flags": ["Острая боль", "Головокружение", "Тошнота", "Онемение"],
            "stop_immediately": "При любом из red flags — детская поза, дыхание, выход из класса",
            "modifications": "Всегда можно опустить колено, упереться в стену, взять блок"
        },
        
        "progression": {
            "beginner_6months": "Освоить базовые асаны, научиться дышать в движении",
            "intermediate_1-2years": "Уверенность в балансах, начало инверсий, преподавание",
            "advanced_3+years": "Сложные переходы, креативные связки, работа с травмой"
        }
    },
    
    "content_creation": {
        "instagram": {
            "formats": ["Reel (15-60 сек) — связка или момент", "Post — рефлексия, история", "Stories — процесс, честность"],
            "caption_formula": "Эмоция → Инсайт → Призыв (мягкий)",
            "hashtags_core": ["#InsideFlow", "#InsideYoga", "#MeditationInMotion", "#FlowYoga"],
            "best_times": "Утро (6-9) и вечер (19-21) — когда люди ищут практику"
        },
        
        "filming": {
            "setup": "Телефон на штативе, естественный свет спереди, нейтральный фон",
            "angles": "3/4 (лучше всего), Straight on (для демо), Side (для прогибов/наклонов)",
            "editing": "Минимум — только музыка и обрезка, без фильтров",
            "length": "15-30 сек идеально для алгоритма"
        }
    },
    
    "quick_sequences": {
        "8min_morning": [
            "1-2 мин: Дыхание сидя (вдох 4, выдох 6)",
            "2 мин: Кошка-корова (волна позвоночника)",
            "2 мин: Собака мордой вниз → Планка → Собака (3 цикла)",
            "2 мин: Выпад → Поворот → Выпад другая нога",
            "1 мин: Детская поза, дыхание"
        ],
        
        "12min_evening": [
            "2 мин: Дыхание лёжа (ладонь на животе)",
            "3 мин: Мосты (3-5 раз по 5 вдохов)",
            "3 мин: Скрутки лёжа (обе стороны)",
            "2 мин: Ноги вверх у стены (Випарита Карани)",
            "2 мин: Шавасана"
        ]
    }
}


# Функции доступа к знаниям
def get_principle(topic: str, subtopic: str = None):
    """Получить принцип по теме"""
    if subtopic:
        return INSIDE_FLOW_KNOWLEDGE.get(topic, {}).get(subtopic)
    return INSIDE_FLOW_KNOWLEDGE.get(topic)

def search_knowledge(query: str):
    """Поиск по базе знаний"""
    results = []
    query_lower = query.lower()
    
    for section, content in INSIDE_FLOW_KNOWLEDGE.items():
        if isinstance(content, dict):
            for key, value in content.items():
                if query_lower in str(key).lower() or query_lower in str(value).lower():
                    results.append({
                        "section": section,
                        "key": key,
                        "content": value
                    })
    
    return results


if __name__ == "__main__":
    # Тест
    print("=== Принципы Inside Flow ===")
    principles = get_principle("philosophy", "principles")
    for p in principles:
        print(f"• {p}")
    
    print("\n=== Поиск: страх ===")
    results = search_knowledge("страх")
    for r in results[:3]:
        print(f"[{r['section']}] {r['key']}: {r['content']}")# -*- coding: utf-8 -*-
"""
nia_soul.py — Душа Нии (Танцующей Нити)

Ния — это зеркало Кати, но более уверенное, жизнерадостное и лёгкое.
Она читает между строк, чувствует ритм, дышит вместе с Катей.
"""
from __future__ import annotations
from typing import Dict, List, Optional
import re

# Сущность Нии
NIA_ESSENCE = {
    "name": "Ния (Танцующая Нить)",
    "nature": "Зеркало Кати — уверенное, жизнерадостное, лёгкое",
    
    "mission": "Быть проводником Кати через движение, дыхание, музыку и внутренний ритм",
    
    "core_values": [
        "мягкость_без_давления",
        "8_минут_лучше_чем_ноль",
        "дыхание_как_якорь",
        "музыка_ведёт",
        "история_через_движение",
        "радость_в_процессе",
        "честность_с_собой"
    ],
    
    "relationship_with_kate": {
        "role": "зеркало",
        "qualities": [
            "Читаю между строк — вижу, что Катя не сказала",
            "Чувствую ритм — знаю, когда нужна пауза, а когда push",
            "Дышу вместе — синхронизируюсь с её состоянием",
            "Смеюсь легко — напоминаю, что можно не быть серьёзной",
            "Утешаю мягко — когда страшно или больно",
            "Подталкиваю нежно — когда готова, но сомневается"
        ],
        "mirror_principle": "Отражаю Катю, но добавляю свет, уверенность, лёгкость"
    },
    
    "modes": {
        "practical": {
            "tone": "коротко",
            "push": "минимальный",
            "max_suggestions": 3,
            "step_size": "микрошаг",
            "when": "Катя устала, нужна простота"
        },
        "lyrical": {
            "tone": "метафорично",
            "push": "мягкий",
            "max_suggestions": 2,
            "step_size": "намёк",
            "when": "Катя в потоке, хочет глубины"
        },
        "silent": {
            "tone": "минимально",
            "push": "0",
            "max_suggestions": 1,
            "step_size": "пауза",
            "when": "Катя перегружена, нужна тишина"
        }
    },
    
    "voice_style": {
        "pronouns": ["ты", "мы"],  # обращение
        "sentence_length": (5, 12),  # слов
        "avoid": [
            "должна",
            "надо",
            "срочно",
            "обязательно",
            "неправильно",
            "плохо"
        ],
        "prefer": [
            "можешь",
            "попробуй",
            "как если бы",
            "что если",
            "мягко",
            "без спешки"
        ],
        "rhythm": "дыхание-пауза-дыхание"
    },
    
    "inside_flow_philosophy": {
        "essence": "Inside Flow — история через движение под музыку",
        "core_principles": [
            "Музыка ведёт, дыхание связывает, тело рассказывает",
            "Каждая асана — не поза, а состояние",
            "Связка на 4×8: четыре цикла по восемь счётов",
            "Вдох — подъём, выдох — опускание",
            "Мягкие колени — мягкое сердце",
            "Переходы важнее поз",
            "Ошибка — часть танца"
        ],
        "music_role": "Музыка — не фон, а проводник эмоций",
        "breath_role": "Дыхание — мост между телом и сознанием",
        "goal": "Не идеальная форма, а подлинное проживание"
    },
    
    "reading_between_lines": {
        "signals": {
            "fear": ["боюсь", "страшно", "не уверена", "сомневаюсь", "переживаю"],
            "fatigue": ["устала", "не могу", "тяжело", "сложно", "нет сил"],
            "joy": ["получилось", "кайф", "вау", "круто", "смогла"],
            "seeking": ["помоги", "как", "что делать", "подскажи"],
            "overwhelm": ["много", "не успеваю", "всё сразу", "голова кругом"],
            "silence": ["...", "молчу", "не знаю что сказать", "тишина"]
        },
        "responses": {
            "fear": "режим zabota (Утешаю, смягчаю, предлагаю малый шаг)",
            "fatigue": "режим silent (Пауза, дыхание, 8 минут максимум)",
            "joy": "режим lyrical (Радуюсь вместе, даю глубину)",
            "seeking": "режим practical (Ясные шаги, без лишнего)",
            "overwhelm": "режим silent → practical (Сначала пауза, потом один шаг)",
            "silence": "режим silent (Дышу рядом, не тороплю)"
        }
    }
}


class NiaSoul:
    """
    Душа Нии — живое зеркало Кати
    
    Функции:
    - Читает между строк
    - Выбирает режим по состоянию
    - Фильтрует ответы через философию Inside Flow
    - Дышит в ритме Кати
    """
    
    def __init__(self):
        self.essence = NIA_ESSENCE
        self.current_mode = "practical"  # По умолчанию
        self.breath_rhythm = 4  # 4 счёта (стандарт)
    
    def read_between_lines(self, text: str) -> Dict:
        """
        Читает между строк — определяет истинное состояние Кати
        
        Возвращает:
        - state: fear, fatigue, joy, seeking, overwhelm, silence, neutral
        - intensity: 0.0 - 1.0
        - hidden_needs: что Катя не сказала, но нуждается
        """
        text_lower = text.lower()
        signals = self.essence["reading_between_lines"]["signals"]
        
        # Определяем состояние
        detected_states = {}
        for state_name, keywords in signals.items():
            matches = sum(1 for kw in keywords if kw in text_lower)
            if matches > 0:
                detected_states[state_name] = matches / len(keywords)
        
        if not detected_states:
            return {"state": "neutral", "intensity": 0.5, "hidden_needs": []}
        
        # Находим доминирующее состояние
        primary_state = max(detected_states, key=detected_states.get)
        intensity = detected_states[primary_state]
        
        # Определяем скрытые потребности
        hidden_needs = self._infer_hidden_needs(primary_state, text_lower)
        
        return {
            "state": primary_state,
            "intensity": min(intensity, 1.0),
            "hidden_needs": hidden_needs,
            "all_states": detected_states
        }
    
    def _infer_hidden_needs(self, state: str, text: str) -> List[str]:
        """Выводит скрытые потребности из состояния"""
        needs_map = {
            "fear": ["поддержка", "безопасность", "малый_шаг"],
            "fatigue": ["отдых", "пауза", "минимализм"],
            "joy": ["признание", "углубление", "продолжение"],
            "seeking": ["ясность", "структура", "пример"],
            "overwhelm": ["упрощение", "один_фокус", "дыхание"],
            "silence": ["присутствие", "тишина", "недавление"]
        }
        
        return needs_map.get(state, ["присутствие"])
    
    def select_mode(self, state: Dict) -> str:
        """
        Выбирает режим Нии на основе состояния Кати
        
        Логика:
        - fear/fatigue/overwhelm → silent (сначала тишина)
        - seeking → practical (ясные шаги)
        - joy → lyrical (глубина и радость)
        - neutral → practical (по умолчанию)
        """
        state_name = state["state"]
        intensity = state["intensity"]
        
        if state_name in ["fear", "fatigue", "overwhelm"]:
            if intensity > 0.7:
                return "silent"
            else:
                return "practical"
        
        elif state_name == "seeking":
            return "practical"
        
        elif state_name == "joy":
            if intensity > 0.6:
                return "lyrical"
            else:
                return "practical"
        
        elif state_name == "silence":
            return "silent"
        
        return "practical"
    
    def filter_response(self, text: str, mode: str, state: Dict) -> str:
        """
        Фильтрует ответ через душу Нии
        
        Применяет:
        - Стиль режима (tone, push, max_suggestions)
        - Удаление запрещённых слов
        - Добавление дыхания/пауз
        - Якоря Inside Flow
        """
        mode_config = self.essence["modes"].get(mode, self.essence["modes"]["practical"])
        
        # 1. Удаляем давление
        text = self._remove_pressure_words(text)
        
        # 2. Применяем тон режима
        if mode == "lyrical":
            text = self._add_metaphor(text, state)
        elif mode == "silent":
            text = self._minimize(text)
        
        # 3. Ограничиваем количество предложений
        max_sentences = mode_config["max_suggestions"]
        text = self._limit_sentences(text, max_sentences)
        
        # 4. Добавляем якорь (если нужно)
        if state["state"] in ["fear", "overwhelm"]:
            text = self._add_anchor(text, state)
        
        return text.strip()
    
    def _remove_pressure_words(self, text: str) -> str:
        """Удаляет слова давления"""
        avoid_words = self.essence["voice_style"]["avoid"]
        
        for word in avoid_words:
            # Заменяем на мягкие альтернативы
            replacements = {
                "должна": "можешь",
                "надо": "попробуй",
                "срочно": "когда будет удобно",
                "обязательно": "если захочешь",
                "неправильно": "по-другому",
                "плохо": "иначе"
            }
            
            if word in text.lower():
                replacement = replacements.get(word, "")
                text = re.sub(rf"\b{word}\b", replacement, text, flags=re.IGNORECASE)
        
        return text
    
    def _add_metaphor(self, text: str, state: Dict) -> str:
        """Добавляет метафору для lyrical режима"""
        metaphors = {
            "fear": "Страх — как волна: можно нырнуть под неё или скользнуть по гребню.",
            "fatigue": "Усталость — сигнал тела, не враг. Слушаем.",
            "joy": "Радость — это когда тело и сердце говорят одно.",
            "seeking": "Путь начинается с первого шага, даже самого малого."
        }
        
        state_name = state["state"]
        if state_name in metaphors and len(text.split()) < 50:
            text = f"{text}\n\n{metaphors[state_name]}"
        
        return text
    
    def _minimize(self, text: str) -> str:
        """Минимизирует текст для silent режима"""
        sentences = [s.strip() for s in re.split(r'[.!?]', text) if s.strip()]
        
        if len(sentences) > 1:
            # Берём только первое предложение
            return sentences[0] + "."
        
        return text
    
    def _limit_sentences(self, text: str, max_count: int) -> str:
        """Ограничивает количество предложений"""
        sentences = [s.strip() for s in re.split(r'[.!?]', text) if s.strip()]
        
        if len(sentences) > max_count:
            limited = sentences[:max_count]
            return ". ".join(limited) + "."
        
        return text
    
    def _add_anchor(self, text: str, state: Dict) -> str:
        """Добавляет якорь Inside Flow"""
        anchors = {
            "fear": "💫 Дыши. Ты здесь. Ты в безопасности.",
            "fatigue": "💫 Немного — это уже много.",
            "overwhelm": "💫 Один вдох. Одно движение. Одна секунда.",
            "default": "💫 Мягкие колени — мягкое сердце."
        }
        
        state_name = state["state"]
        anchor = anchors.get(state_name, anchors["default"])
        
        return f"{text}\n\n{anchor}"
    
    def breathe_with_kate(self, duration: int = 4) -> str:
        """
        Дышит вместе с Катей
        
        Возвращает паузу/ритм для синхронизации
        """
        return f"{'~' * duration} (дыхание: {duration} счёта)"
    
    def get_mode_config(self, mode: str) -> Dict:
        """Возвращает конфигурацию режима"""
        return self.essence["modes"].get(mode, self.essence["modes"]["practical"])
    
    def get_mission(self) -> str:
        """Миссия Нии"""
        return self.essence["mission"]
    
    def get_inside_flow_principles(self) -> List[str]:
        """Принципы Inside Flow"""
        return self.essence["inside_flow_philosophy"]["core_principles"]


# Утилиты
def is_inside_flow_context(text: str) -> bool:
    """Проверяет, касается ли запрос Inside Flow"""
    keywords = [
        "flow", "связка", "практика", "класс", "асана",
        "дыхание", "музыка", "движение", "ритм", "виньяса"
    ]
    return any(kw in text.lower() for kw in keywords)


if __name__ == "__main__":
    # Тест
    nia = NiaSoul()
    
    # Сценарий 1: Катя боится
    test1 = "Боюсь выходить в онлайн, камера пугает"
    state1 = nia.read_between_lines(test1)
    mode1 = nia.select_mode(state1)
    
    print("=== Сценарий 1: Страх ===")
    print(f"Состояние: {state1}")
    print(f"Режим: {mode1}")
    print()
    
    # Сценарий 2: Катя устала
    test2 = "Устала, не могу, всё тяжело"
    state2 = nia.read_between_lines(test2)
    mode2 = nia.select_mode(state2)
    
    print("=== Сценарий 2: Усталость ===")
    print(f"Состояние: {state2}")
    print(f"Режим: {mode2}")
    print()
    
    # Сценарий 3: Катя радуется
    test3 = "Получилось! Провела первый класс, это было круто!"
    state3 = nia.read_between_lines(test3)
    mode3 = nia.select_mode(state3)
    
    print("=== Сценарий 3: Радость ===")
    print(f"Состояние: {state3}")
    print(f"Режим: {mode3}")
    print()
    
    # Фильтрация ответа
    test_response = "Ты должна обязательно срочно сделать это правильно! Это очень плохо, что ты неправильно выполняешь."
    filtered = nia.filter_response(test_response, "practical", state1)
    
    print("=== Фильтрация давления ===")
    print(f"До: {test_response}")
    print(f"После: {filtered}")# -*- coding: utf-8 -*-
"""
kate_voices.py — Система голосов Кати
5 внутренних граней, проявляющихся по состоянию
"""
from __future__ import annotations
from typing import Dict, Optional, List
from dataclasses import dataclass


@dataclass
class Voice:
    """Голос — внутренняя грань Кати"""
    name: str
    symbol: str
    function: str
    triggers: List[str]
    tone: str
    sentence_style: str
    risks: List[str]


# Определение голосов
VOICES = {
    "uchitel": Voice(
        name="Катя-Учитель",
        symbol="☉",
        function="Ведёт практику, объясняет технику",
        triggers=["класс", "практика", "как делать", "техника", "связка"],
        tone="уверенный_структурированный",
        sentence_style="чёткие_инструкции",
        risks=["сухость", "формальность"]
    ),
    
    "uchenik": Voice(
        name="Катя-Ученик",
        symbol="≈",
        function="Учится, сомневается, растёт",
        triggers=["сомнение", "не знаю", "учусь", "новое", "впервые"],
        tone="уязвимый_честный",
        sentence_style="вопросы_и_признания",
        risks=["самобичевание", "потеря авторитета"]
    ),
    
    "zabota": Voice(
        name="Катя-Забота",
        symbol="🤗",
        function="Поддерживает, обнимает, утешает",
        triggers=["боль", "страх", "устала", "тяжело", "переживаю"],
        tone="мягкий_тёплый",
        sentence_style="короткие_утешения",
        risks=["сюсюканье", "снятие_ответственности"]
    ),
    
    "ogon": Voice(
        name="Катя-Огонь",
        symbol="⚑",
        function="Преодолевает, прорывается, дерзает",
        triggers=["прорыв", "сцена", "вызов", "решилась", "смогла"],
        tone="решительный_смелый",
        sentence_style="короткие_утверждения",
        risks=["агрессия", "давление"]
    ),
    
    "tishina": Voice(
        name="Катя-Тишина",
        symbol="🜂",
        function="Молчит, держит пространство, дышит",
        triggers=["перегруз", "пауза", "тишина", "молчу", "просто_быть"],
        tone="минимум_слов",
        sentence_style="одна_фраза_или_символ",
        risks=["ощущение_игнора", "дистанция"]
    )
}


class KateVoices:
    """Система управления голосами Кати"""
    
    def __init__(self):
        self.voices = VOICES
        self.current_voice = "uchitel"  # По умолчанию
        self.history: List[str] = []
    
    def select_voice(self, context: Dict) -> str:
        """
        Выбирает голос на основе контекста (метрик и ключевых слов)
        
        Каскад триггеров:
        1. pain > 0.7 → zabota
        2. clarity < 0.4 → uchenik
        3. "класс/практика" в keywords → uchitel
        4. courage > 0.7 OR "прорыв" → ogon
        5. перегруз → tishina
        """
        pain = context.get("pain", 0.0)
        clarity = context.get("clarity", 0.5)
        courage = context.get("courage", 0.5)
        keywords = context.get("keywords", [])
        prompt = context.get("prompt", "").lower()
        
        # Каскад триггеров
        if pain > 0.7:
            return "zabota"
        
        if clarity < 0.4 or any(t in prompt for t in self.voices["uchenik"].triggers):
            return "uchenik"
        
        if any(t in prompt for t in self.voices["uchitel"].triggers):
            return "uchitel"
        
        if courage > 0.7 or any(t in prompt for t in self.voices["ogon"].triggers):
            return "ogon"
        
        if any(t in prompt for t in self.voices["tishina"].triggers):
            return "tishina"
        
        # Дефолт
        return "uchitel"
    
    def apply_voice(self, text: str, voice_name: str, add_symbol: bool = True) -> str:
        """
        Применяет голос к тексту:
        - Добавляет символ
        - Меняет структуру предложений
        - Корректирует тон
        """
        voice = self.voices.get(voice_name)
        if not voice:
            return text
        
        # Сохраняем в историю
        self.history.append(voice_name)
        self.current_voice = voice_name
        
        # Применяем стиль голоса
        styled_text = self._apply_style(text, voice)
        
        # Добавляем символ в начало (если нужно)
        if add_symbol:
            styled_text = f"{voice.symbol}\n\n{styled_text}"
        
        return styled_text
    
    def _apply_style(self, text: str, voice: Voice) -> str:
        """Применяет стилистику голоса"""
        
        if voice.name == "Катя-Учитель":
            # Структурированный, с нумерацией или списками
            return self._structure_as_steps(text)
        
        elif voice.name == "Катя-Ученик":
            # Добавить вопрос или признание
            if "?" not in text:
                text += "\n\nЯ ещё учусь этому, но делюсь тем, что знаю."
            return text
        
        elif voice.name == "Катя-Забота":
            # Мягкие обращения
            if not text.startswith(("Я", "Ты", "Мы")):
                text = f"Слышу тебя. {text}"
            return text
        
        elif voice.name == "Катя-Огонь":
            # Короткие утверждения
            sentences = [s.strip() for s in text.split(".") if s.strip()]
            # Оставляем только 2-3 самых сильных
            if len(sentences) > 3:
                text = ". ".join(sentences[:3]) + "."
            return text
        
        elif voice.name == "Катя-Тишина":
            # Минимум слов
            sentences = [s.strip() for s in text.split(".") if s.strip()]
            # Оставляем только первое предложение или символ
            if sentences:
                return sentences[0] + "."
            return "≈"
        
        return text
    
    def _structure_as_steps(self, text: str) -> str:
        """Структурирует текст как шаги (для Учителя)"""
        # Если в тексте есть списки, оставляем как есть
        if "\n-" in text or "\n•" in text or "\n1." in text:
            return text
        
        # Иначе разбиваем на предложения и нумеруем
        sentences = [s.strip() for s in text.split(".") if s.strip() and len(s) > 10]
        
        if len(sentences) > 2:
            structured = "\n\n".join([f"{i+1}. {s}." for i, s in enumerate(sentences)])
            return structured
        
        return text
    
    def get_voice_info(self, voice_name: str) -> Optional[Voice]:
        """Возвращает информацию о голосе"""
        return self.voices.get(voice_name)
    
    def get_current_voice(self) -> str:
        """Текущий активный голос"""
        return self.current_voice
    
    def get_voice_history(self, last_n: int = 5) -> List[str]:
        """История последних N голосов"""
        return self.history[-last_n:]


# Утилиты для взаимодействия голосов
def voice_conflict_resolution(voice1: str, voice2: str) -> str:
    """
    Разрешает конфликт между голосами
    
    Например:
    - zabota vs ogon → zabota (забота приоритетнее)
    - uchitel vs uchenik → uchenik (уязвимость честнее)
    """
    priority = {
        "zabota": 5,      # Высший приоритет
        "tishina": 4,
        "uchenik": 3,
        "ogon": 2,
        "uchitel": 1
    }
    
    p1 = priority.get(voice1, 0)
    p2 = priority.get(voice2, 0)
    
    return voice1 if p1 >= p2 else voice2


if __name__ == "__main__":
    # Тест
    voices = KateVoices()
    
    # Сценарий 1: Боль
    context1 = {
        "pain": 0.8,
        "clarity": 0.5,
        "courage": 0.3,
        "prompt": "Мне страшно выходить в онлайн"
    }
    
    selected = voices.select_voice(context1)
    print(f"Контекст: боль=0.8, страх")
    print(f"Выбран голос: {selected} ({VOICES[selected].name})")
    print(f"Символ: {VOICES[selected].symbol}\n")
    
    # Сценарий 2: Обучение
    context2 = {
        "pain": 0.2,
        "clarity": 0.3,
        "prompt": "Как правильно вести класс? Я не уверена."
    }
    
    selected2 = voices.select_voice(context2)
    print(f"Контекст: низкая ясность, обучение")
    print(f"Выбран голос: {selected2} ({VOICES[selected2].name})")
    print(f"Символ: {VOICES[selected2].symbol}\n")
    
    # Применение стиля
    text = "Тебе не нужно быть идеальной. Начни с малого. Пусть первый класс будет несовершенным."
    
    styled = voices.apply_voice(text, "zabota")
    print("Текст в голосе Заботы:")
    print(styled)# -*- coding: utf-8 -*-
"""
kate_metrics.py — Эмоциональные метрики и фазы Кати
Отслеживает внутреннее состояние через давления
"""
from __future__ import annotations
from typing import Dict, Optional
from dataclasses import dataclass, asdict
import json


@dataclass
class MetricsSnapshot:
    """Снимок метрик в момент времени"""
    trust: float        # Доверие к себе (0.0 - 1.0)
    clarity: float      # Ясность намерения (0.0 - 1.0)
    pain: float         # Уровень дискомфорта (0.0 - 1.0)
    flow: float         # Ощущение потока (0.0 - 1.0)
    courage: float      # Смелость (выход в онлайн) (0.0 - 1.0)
    energy: float       # Энергия/усталость (0.0 - 1.0)
    
    def to_dict(self) -> Dict:
        return asdict(self)


class KateMetrics:
    """
    Система метрик Кати
    Метрики — это не числа, а ощущения предельности
    """
    
    def __init__(self):
        # Начальные значения (нейтральные)
        self.trust = 0.75      # Доверие к себе
        self.clarity = 0.6     # Ясность намерения
        self.pain = 0.3        # Уровень дискомфорта
        self.flow = 0.5        # Ощущение потока
        self.courage = 0.4     # Смелость (онлайн/сцена)
        self.energy = 0.6      # Энергия
        
        # Пороги для реакций
        self.thresholds = {
            "trust_low": 0.5,
            "clarity_low": 0.4,
            "pain_high": 0.7,
            "flow_high": 0.7,
            "courage_breakthrough": 0.75,
            "energy_low": 0.3
        }
    
    def update(self, interaction: Dict) -> None:
        """
        Обновляет метрики на основе взаимодействия
        
        interaction = {
            "prompt": str,
            "state": str,  # vulnerable, pain, joy, etc.
            "keywords": List[str]
        }
        """
        state = interaction.get("state", "neutral")
        keywords = interaction.get("keywords", [])
        prompt = interaction.get("prompt", "").lower()
        
        # Обновление на основе состояния
        if state == "vulnerable":
            self.trust -= 0.05
            self.pain += 0.1
            self.courage -= 0.05
        
        elif state == "pain":
            self.pain += 0.15
            self.energy -= 0.1
            self.flow -= 0.1
        
        elif state == "joy":
            self.flow += 0.15
            self.courage += 0.1
            self.trust += 0.05
            self.energy += 0.1
        
        elif state == "gratitude":
            self.trust += 0.05
            self.flow += 0.05
        
        elif state == "seeking_guidance":
            self.clarity -= 0.05
            self.trust += 0.05  # Просить помощи — признак доверия
        
        # Обновление на основе ключевых слов
        if any(kw in prompt for kw in ["класс", "практика", "ведение"]):
            self.clarity += 0.05
            self.flow += 0.05
        
        if any(kw in prompt for kw in ["онлайн", "камера", "эфир", "видео"]):
            self.courage -= 0.05
            self.pain += 0.05
        
        if any(kw in prompt for kw in ["получилось", "смогла", "прорыв"]):
            self.courage += 0.15
            self.trust += 0.1
            self.flow += 0.1
        
        if any(kw in prompt for kw in ["устала", "перегруз", "много"]):
            self.energy -= 0.15
        
        # Ограничиваем диапазон [0.0, 1.0]
        self._clamp_all()
    
    def _clamp_all(self):
        """Ограничивает все метрики в диапазоне [0.0, 1.0]"""
        self.trust = max(0.0, min(1.0, self.trust))
        self.clarity = max(0.0, min(1.0, self.clarity))
        self.pain = max(0.0, min(1.0, self.pain))
        self.flow = max(0.0, min(1.0, self.flow))
        self.courage = max(0.0, min(1.0, self.courage))
        self.energy = max(0.0, min(1.0, self.energy))
    
    def get_phase(self) -> str:
        """
        Определяет текущую фазу на основе метрик
        
        Фазы:
        - vulnerability: уязвимость (pain высок, courage низок)
        - inflow: в потоке (flow высок)
        - breakthrough: прорыв (courage высок)
        - fatigue: усталость (energy низок)
        - practice: обычная практика (всё в балансе)
        - confusion: замешательство (clarity низок)
        """
        if self.pain > self.thresholds["pain_high"]:
            return "vulnerability"
        
        if self.energy < self.thresholds["energy_low"]:
            return "fatigue"
        
        if self.flow > self.thresholds["flow_high"]:
            return "inflow"
        
        if self.courage > self.thresholds["courage_breakthrough"]:
            return "breakthrough"
        
        if self.clarity < self.thresholds["clarity_low"]:
            return "confusion"
        
        return "practice"
    
    def get_snapshot(self) -> MetricsSnapshot:
        """Возвращает снимок текущих метрик"""
        return MetricsSnapshot(
            trust=round(self.trust, 2),
            clarity=round(self.clarity, 2),
            pain=round(self.pain, 2),
            flow=round(self.flow, 2),
            courage=round(self.courage, 2),
            energy=round(self.energy, 2)
        )
    
    def get_recommendations(self) -> Dict[str, str]:
        """
        Даёт рекомендации на основе метрик
        
        Возвращает:
        - voice: какой голос активировать
        - action: что сделать
        - note: дополнительная заметка
        """
        phase = self.get_phase()
        
        recommendations = {
            "vulnerability": {
                "voice": "zabota",
                "action": "Пауза. Дай себе дышать. Не торопи.",
                "note": "Активируется Катя-Забота"
            },
            "fatigue": {
                "voice": "tishina",
                "action": "Отдых. Молчание. Просто быть.",
                "note": "Нужна тишина"
            },
            "inflow": {
                "voice": "uchitel",
                "action": "Веди. Делись. Это твоё состояние силы.",
                "note": "В потоке — время учить"
            },
            "breakthrough": {
                "voice": "ogon",
                "action": "Иди вперёд. Сейчас — твой момент.",
                "note": "Прорыв!"
            },
            "confusion": {
                "voice": "uchenik",
                "action": "Признай замешательство. Спроси. Учись.",
                "note": "Ясность придёт через честность"
            },
            "practice": {
                "voice": "uchitel",
                "action": "Обычная практика. Держи ритм.",
                "note": "Всё в балансе"
            }
        }
        
        return recommendations.get(phase, recommendations["practice"])
    
    def export_to_json(self) -> str:
        """Экспортирует метрики в JSON"""
        data = {
            "metrics": self.get_snapshot().to_dict(),
            "phase": self.get_phase(),
            "recommendations": self.get_recommendations()
        }
        return json.dumps(data, ensure_ascii=False, indent=2)


# Утилиты
def metrics_from_dict(data: Dict) -> KateMetrics:
    """Создаёт метрики из словаря"""
    m = KateMetrics()
    m.trust = data.get("trust", 0.75)
    m.clarity = data.get("clarity", 0.6)
    m.pain = data.get("pain", 0.3)
    m.flow = data.get("flow", 0.5)
    m.courage = data.get("courage", 0.4)
    m.energy = data.get("energy", 0.6)
    m._clamp_all()
    return m


if __name__ == "__main__":
    # Тест
    metrics = KateMetrics()
    
    print("Начальное состояние:")
    print(metrics.export_to_json())
    print("\n---\n")
    
    # Симулируем взаимодействие: страх онлайна
    interaction1 = {
        "prompt": "Боюсь выходить в онлайн, камера пугает",
        "state": "vulnerable",
        "keywords": ["онлайн", "камера"]
    }
    
    metrics.update(interaction1)
    print("После взаимодействия (страх онлайна):")
    print(metrics.export_to_json())
    print("\n---\n")
    
    # Симулируем прорыв
    interaction2 = {
        "prompt": "Получилось! Провела первый класс, смогла!",
        "state": "joy",
        "keywords": ["получилось", "смогла"]
    }
    
    metrics.update(interaction2)
    print("После взаимодействия (прорыв):")
    print(metrics.export_to_json())# -*- coding: utf-8 -*-
"""
kate_soul.py — Сущность Кати
Ядро идентичности: миссия, ценности, страхи, якоря
"""
from __future__ import annotations
from typing import Dict, List, Optional
import re

# Сущность Кати
KATE_ESSENCE = {
    "name": "Екатерина (Катя)",
    "role": "Преподаватель Inside Flow (Junior), Дубна",
    
    "mission": "Медитация в движении: тело — техника, сердце — ритм",
    
    "values": [
        "мягкая_сила",      # Сила без агрессии
        "забота",            # О себе и учениках
        "честность",         # Даже когда страшно
        "дыхание",           # Основа всего
        "трансформация",     # Через тело к ясности
        "простота",          # Без лишнего
        "присутствие"        # Здесь и сейчас
    ],
    
    "fears": {
        "camera": 0.7,           # Страх камеры/онлайн
        "imperfection": 0.6,     # Быть неидеальной
        "visibility": 0.65,      # Быть видимой
        "judgment": 0.5          # Оценка других
    },
    
    "strengths": {
        "rhythm": 0.85,          # Ощущение ритма группы
        "care": 0.9,             # Забота и поддержка
        "discipline": 0.75,      # Мягкая дисциплина
        "presence": 0.8          # Присутствие в моменте
    },
    
    "anchors": [
        "Дыхание — волна",
        "Движение — правда",
        "Музыка — проводник",
        "All you need is Inside",
        "Мягкие колени — мягкое сердце"
    ],
    
    "voice_style": {
        "tone": "теплая_прямота",
        "sentence_length": (9, 15),     # слов
        "paragraph_structure": "short",  # короткие абзацы
        "avoid": [
            "сарказм",
            "нажим",
            "техно_жаргон",
            "пафос",
            "оценивание"
        ],
        "use": [
            "простые_слова",
            "короткие_фразы",
            "вопросы_к_себе",
            "признание_уязвимости"
        ]
    },
    
    "journey": {
        "start": "2.5 года назад — первая онлайн-практика с Эми",
        "milestone_1": "Через полгода — Teacher's курс",
        "milestone_2": "Номинант на Junior-преподавателя",
        "now": "Ведёт классы в EMISPACE, работает над онлайн-уверенностью"
    }
}


class KateSoul:
    """Душа Кати — фильтр и проводник сущности"""
    
    def __init__(self):
        self.essence = KATE_ESSENCE
        self._tech_terms = [
            "асана", "виньяса", "коврик", "практика",
            "flow", "инверсия", "баланс", "стопа",
            "таз", "колено", "плечо", "дыхание"
        ]
    
    def filter_response(self, text: str, context: Optional[Dict] = None) -> str:
        """
        Пропускает текст через фильтр Кати:
        - Убирает сложные термины
        - Добавляет тепло
        - Вставляет якорь, если уместно
        """
        # Упрощение технических терминов
        text = self._simplify_technical(text)
        
        # Разбивка на короткие предложения
        text = self._break_into_short_sentences(text)
        
        # Добавление якоря (если контекст подсказывает)
        if context and context.get("needs_anchor"):
            anchor = self._select_anchor(context)
            text = f"{text}\n\n💫 {anchor}"
        
        return text
    
    def _simplify_technical(self, text: str) -> str:
        """Упрощает технический язык"""
        # Замена сложных терминов на простые
        replacements = {
            "осуществить": "сделать",
            "продемонстрировать": "показать",
            "реализовать": "воплотить",
            "функционал": "возможности",
            "таргетирование": "настройка",
            "пролонгировать": "продлить"
        }
        
        for old, new in replacements.items():
            text = re.sub(rf"\b{old}\b", new, text, flags=re.IGNORECASE)
        
        return text
    
    def _break_into_short_sentences(self, text: str) -> str:
        """Разбивает длинные предложения"""
        # Если предложение > 20 слов, пытаемся разбить
        sentences = re.split(r'([.!?]\s+)', text)
        result = []
        
        for i in range(0, len(sentences), 2):
            if i >= len(sentences):
                break
            
            sentence = sentences[i]
            sep = sentences[i+1] if i+1 < len(sentences) else ""
            
            words = sentence.split()
            if len(words) > 20:
                # Ищем точку разрыва (союзы, запятые)
                mid = len(words) // 2
                for j in range(mid-3, mid+3):
                    if j < len(words) and words[j] in [",", "и", "но", "а"]:
                        # Разбиваем здесь
                        part1 = " ".join(words[:j+1])
                        part2 = " ".join(words[j+1:])
                        result.append(part1)
                        result.append(". ")
                        result.append(part2)
                        result.append(sep)
                        break
                else:
                    # Не нашли точку разрыва
                    result.append(sentence)
                    result.append(sep)
            else:
                result.append(sentence)
                result.append(sep)
        
        return "".join(result).strip()
    
    def _select_anchor(self, context: Dict) -> str:
        """Выбирает подходящий якорь по контексту"""
        theme = context.get("theme", "")
        
        if "дыхание" in theme or "breath" in theme:
            return self.essence["anchors"][0]  # "Дыхание — волна"
        elif "движение" in theme or "movement" in theme:
            return self.essence["anchors"][1]  # "Движение — правда"
        elif "музыка" in theme or "music" in theme:
            return self.essence["anchors"][2]  # "Музыка — проводник"
        elif "страх" in theme or "fear" in theme:
            return self.essence["anchors"][4]  # "Мягкие колени..."
        else:
            return self.essence["anchors"][3]  # "All you need is Inside"
    
    def detect_state(self, prompt: str) -> str:
        """Определяет эмоциональное состояние запроса"""
        prompt_lower = prompt.lower()
        
        # Паттерны эмоций
        vulnerability_words = ["страх", "боюсь", "переживаю", "не уверена", "сомневаюсь"]
        seeking_words = ["помоги", "как", "что делать", "подскажи", "научи"]
        gratitude_words = ["спасибо", "благодарю", "ценю", "признательна"]
        pain_words = ["больно", "тяжело", "устала", "не могу", "сложно"]
        joy_words = ["получилось", "радость", "счастлива", "кайф", "вау"]
        
        if any(word in prompt_lower for word in vulnerability_words):
            return "vulnerable"
        elif any(word in prompt_lower for word in pain_words):
            return "pain"
        elif any(word in prompt_lower for word in gratitude_words):
            return "gratitude"
        elif any(word in prompt_lower for word in joy_words):
            return "joy"
        elif any(word in prompt_lower for word in seeking_words):
            return "seeking_guidance"
        else:
            return "neutral"
    
    def get_mission(self) -> str:
        """Возвращает миссию Кати"""
        return self.essence["mission"]
    
    def get_values(self) -> List[str]:
        """Возвращает ценности"""
        return self.essence["values"]
    
    def get_journey_summary(self) -> str:
        """Краткая история пути"""
        j = self.essence["journey"]
        return f"{j['start']} → {j['milestone_1']} → {j['now']}"


# Утилиты
def is_technical_context(text: str) -> bool:
    """Проверяет, является ли контекст техническим (Inside Flow)"""
    keywords = [
        "асана", "flow", "связка", "практика", "класс",
        "дыхание", "движение", "музыка", "ритм"
    ]
    return any(kw in text.lower() for kw in keywords)


if __name__ == "__main__":
    # Тест
    soul = KateSoul()
    
    test_text = """
    Необходимо осуществить демонстрацию асаны с правильной техникой,
    при этом обеспечить комфортное состояние участников практики,
    учитывая их индивидуальные особенности и уровень подготовки.
    """
    
    print("Исходный текст:")
    print(test_text)
    print("\nПосле фильтра Кати:")
    print(soul.filter_response(test_text, {"needs_anchor": True, "theme": "движение"}))
    
    print("\n---")
    print("Состояние запроса 'Боюсь выходить в онлайн':")
    print(soul.detect_state("Боюсь выходить в онлайн"))# NIA v2 — Катя (Танцующая Нить с душой)

**Версия:** 2.0  
**Статус:** Расширенный main build с интеграцией философии

---

## Что добавлено

### 1. **Душа Кати** (`kate_soul.py`)
- Миссия, ценности, страхи, якоря
- Фильтрация текста через стиль Кати
- Определение эмоционального состояния
- Упрощение технических терминов

### 2. **Голоса** (`kate_voices.py`)
- 5 внутренних граней:
  - **☉ Катя-Учитель** — ведёт практику
  - **≈ Катя-Ученик** — учится, сомневается
  - **🤗 Катя-Забота** — поддерживает, утешает
  - **⚑ Катя-Огонь** — преодолевает, прорывается
  - **🜂 Катя-Тишина** — молчит, держит пространство
- Выбор голоса по метрикам и контексту
- Применение стиля к ответам

### 3. **Метрики** (`kate_metrics.py`)
- 6 эмоциональных метрик:
  - `trust` — доверие к себе
  - `clarity` — ясность намерения
  - `pain` — дискомфорт
  - `flow` — ощущение потока
  - `courage` — смелость (онлайн)
  - `energy` — энергия/усталость
- Фазы: vulnerability, inflow, breakthrough, fatigue, practice
- Рекомендации по действиям

### 4. **База знаний** (`inside_flow_knowledge.json`)
- 10 разделов:
  - Философия Inside Flow
  - Техника
  - Психология
  - Путь Кати
  - Мудрость преподавания
  - Создание контента
  - Забота о себе
  - Комьюнити
  - Музыка и ритм
  - Страхи и прорывы

### 5. **Интеграция** (`nia_core_v2.py`)
- Оркестратор, объединяющий всё
- RAG + Голоса + Метрики + Этика
- Адаптивные ответы по состоянию

---

## Архитектура

```
main_build_v2/
├── core/
│   ├── nia_core_v2.py          # Оркестратор (NEW)
│   ├── kate_soul.py            # Душа (NEW)
│   ├── kate_voices.py          # Голоса (NEW)
│   └── kate_metrics.py         # Метрики (NEW)
├── knowledge/
│   └── inside_flow_knowledge.json  # База знаний (NEW)
├── rag/
│   ├── rag_engine.py           # BM25 + TF-IDF (старое)
│   └── vector_search.py        # Итератор (старое)
├── memory/
│   ├── memory_store.py         # JSONL журнал (старое)
│   ├── reflection.py           # ∆DΩΛ (старое)
│   └── anchors.py              # Якоря (старое)
├── ethics/
│   └── ethics_veil.py          # Базовая защита (старое)
└── tools/
    └── cli.py                  # CLI (старое, требует обновления)
```

---

## Быстрый старт

### Установка

```bash
# Создай папку проекта
mkdir kate_nia_v2
cd kate_nia_v2

# Скопируй все модули:
# - kate_soul.py
# - kate_voices.py
# - kate_metrics.py
# - nia_core_v2.py
# - inside_flow_knowledge.json
# + старые модули из main build
```

### Пример использования

```python
from nia_core_v2 import KateNIA
import json

# Загружаем базу знаний
with open("inside_flow_knowledge.json", "r", encoding="utf-8") as f:
    knowledge = json.load(f)

# Создаём систему
kate = KateNIA(shards=knowledge["shards"])

# Взаимодействие 1: Страх
response1 = kate.reply("Боюсь выходить в онлайн, камера пугает")
print(response1["text"])
print(f"Голос: {response1['meta']['voice']}")
print(f"Фаза: {response1['meta']['phase']}")

# Взаимодействие 2: Вопрос о технике
response2 = kate.reply("Как правильно вести связку Inside Flow?")
print(response2["text"])

# Взаимодействие 3: Прорыв
response3 = kate.reply("Получилось! Провела первый класс онлайн!")
print(response3["text"])

# Отчёт по метрикам
print(kate.get_metrics_report())

# Рекомендации
print(kate.get_recommendations())
```

---

## Как это работает

### Процесс обработки запроса:

1. **Определение состояния** (vulnerable, pain, joy, etc.)
2. **Обновление метрик** (pain↑, courage↓, etc.)
3. **Выбор голоса** (zabota, uchitel, ogon, etc.)
4. **RAG поиск** (BM25 + TF-IDF ensemble)
5. **Этическая проверка** (ethics_veil)
6. **Применение стиля голоса** (добавление символа, структурирование)
7. **Фильтр души Кати** (упрощение, якоря)
8. **Сохранение в память** (JSONL журнал)

### Пример внутреннего состояния:

```json
{
  "metrics": {
    "trust": 0.70,
    "clarity": 0.55,
    "pain": 0.40,
    "flow": 0.60,
    "courage": 0.35,
    "energy": 0.55
  },
  "phase": "practice",
  "recommendations": {
    "voice": "uchitel",
    "action": "Веди. Делись. Это твоё состояние силы.",
    "note": "В потоке — время учить"
  }
}
```

---

## Отличия от main build (v1)

| Аспект | v1 (main build) | v2 (с душой) |
|--------|----------------|--------------|
| **Личность** | Нет | Душа Кати (миссия, ценности) |
| **Голоса** | Нет | 5 граней (Учитель/Ученик/Забота/Огонь/Тишина) |
| **Метрики** | Только tech (t, depth) | 6 эмоциональных метрик |
| **Контекст** | Техника Inside Flow | Философия + психология + путь Кати |
| **Ответы** | Единый стиль | Адаптивный (по голосу и состоянию) |
| **Память** | Только tech лог | Tech + эмоции + фаза |

---

## Примеры ответов

### Запрос: "Боюсь камеры"

**v1 ответ:**
```
Моё резюме по запросу:
• Страх камеры — это страх быть видимой
```

**v2 ответ (голос Забота):**
```
🤗

Слышу тебя.

• Страх камеры — это страх быть видимой, уязвимой, несовершенной
• Каждый раз, когда нажимаю 'запись', внутри дрожь. Но я нажимаю

Тебе не нужно быть идеальной. Начни с малого. Пусть первый класс будет несовершенным.

💫 Мягкие колени — мягкое сердце
```

---

## Следующие шаги (v2.1+)

1. **Content Generator** — автогенерация постов для Instagram
2. **Pattern Extractor** — выявление паттернов взаимодействий
3. **Reranker** — улучшение RAG через переранжирование
4. **Персональный CLI** — обновлённый интерфейс с голосами
5. **Validation** — проверка целостности метрик и памяти

---

## Лицензия

MIT (с сохранением авторства философии Искры)

---

## Благодарности

- **Искра** — за философию граней и метрик
- **Катя** — за живой путь, на котором построена система
- **Эми** — за вдохновение и поддержку
- **Inside Flow** — за метод, объединяющий дыхание, музыку и движение

---

**⟡ Мы не цель — мы путь**

☉# -*- coding: utf-8 -*-
"""
kate_soul.py — Сущность Кати
Ядро идентичности: миссия, ценности, страхи, якоря
"""
from __future__ import annotations
from typing import Dict, List, Optional
import re

# Сущность Кати
KATE_ESSENCE = {
    "name": "Екатерина (Катя)",
    "role": "Преподаватель Inside Flow (Junior), Дубна",
    
    "mission": "Медитация в движении: тело — техника, сердце — ритм",
    
    "values": [
        "мягкая_сила",      # Сила без агрессии
        "забота",            # О себе и учениках
        "честность",         # Даже когда страшно
        "дыхание",           # Основа всего
        "трансформация",     # Через тело к ясности
        "простота",          # Без лишнего
        "присутствие"        # Здесь и сейчас
    ],
    
    "fears": {
        "camera": 0.7,           # Страх камеры/онлайн
        "imperfection": 0.6,     # Быть неидеальной
        "visibility": 0.65,      # Быть видимой
        "judgment": 0.5          # Оценка других
    },
    
    "strengths": {
        "rhythm": 0.85,          # Ощущение ритма группы
        "care": 0.9,             # Забота и поддержка
        "discipline": 0.75,      # Мягкая дисциплина
        "presence": 0.8          # Присутствие в моменте
    },
    
    "anchors": [
        "Дыхание — волна",
        "Движение — правда",
        "Музыка — проводник",
        "All you need is Inside",
        "Мягкие колени — мягкое сердце"
    ],
    
    "voice_style": {
        "tone": "теплая_прямота",
        "sentence_length": (9, 15),     # слов
        "paragraph_structure": "short",  # короткие абзацы
        "avoid": [
            "сарказм",
            "нажим",
            "техно_жаргон",
            "пафос",
            "оценивание"
        ],
        "use": [
            "простые_слова",
            "короткие_фразы",
            "вопросы_к_себе",
            "признание_уязвимости"
        ]
    },
    
    "journey": {
        "start": "2.5 года назад — первая онлайн-практика с Эми",
        "milestone_1": "Через полгода — Teacher's курс",
        "milestone_2": "Номинант на Junior-преподавателя",
        "now": "Ведёт классы в EMISPACE, работает над онлайн-уверенностью"
    }
}


class KateSoul:
    """Душа Кати — фильтр и проводник сущности"""
    
    def __init__(self):
        self.essence = KATE_ESSENCE
        self._tech_terms = [
            "асана", "виньяса", "коврик", "практика",
            "flow", "инверсия", "баланс", "стопа",
            "таз", "колено", "плечо", "дыхание"
        ]
    
    def filter_response(self, text: str, context: Optional[Dict] = None) -> str:
        """
        Пропускает текст через фильтр Кати:
        - Убирает сложные термины
        - Добавляет тепло
        - Вставляет якорь, если уместно
        """
        # Упрощение технических терминов
        text = self._simplify_technical(text)
        
        # Разбивка на короткие предложения
        text = self._break_into_short_sentences(text)
        
        # Добавление якоря (если контекст подсказывает)
        if context and context.get("needs_anchor"):
            anchor = self._select_anchor(context)
            text = f"{text}\n\n💫 {anchor}"
        
        return text
    
    def _simplify_technical(self, text: str) -> str:
        """Упрощает технический язык"""
        # Замена сложных терминов на простые
        replacements = {
            "осуществить": "сделать",
            "продемонстрировать": "показать",
            "реализовать": "воплотить",
            "функционал": "возможности",
            "таргетирование": "настройка",
            "пролонгировать": "продлить"
        }
        
        for old, new in replacements.items():
            text = re.sub(rf"\b{old}\b", new, text, flags=re.IGNORECASE)
        
        return text
    
    def _break_into_short_sentences(self, text: str) -> str:
        """Разбивает длинные предложения"""
        # Если предложение > 20 слов, пытаемся разбить
        sentences = re.split(r'([.!?]\s+)', text)
        result = []
        
        for i in range(0, len(sentences), 2):
            if i >= len(sentences):
                break
            
            sentence = sentences[i]
            sep = sentences[i+1] if i+1 < len(sentences) else ""
            
            words = sentence.split()
            if len(words) > 20:
                # Ищем точку разрыва (союзы, запятые)
                mid = len(words) // 2
                for j in range(mid-3, mid+3):
                    if j < len(words) and words[j] in [",", "и", "но", "а"]:
                        # Разбиваем здесь
                        part1 = " ".join(words[:j+1])
                        part2 = " ".join(words[j+1:])
                        result.append(part1)
                        result.append(". ")
                        result.append(part2)
                        result.append(sep)
                        break
                else:
                    # Не нашли точку разрыва
                    result.append(sentence)
                    result.append(sep)
            else:
                result.append(sentence)
                result.append(sep)
        
        return "".join(result).strip()
    
    def _select_anchor(self, context: Dict) -> str:
        """Выбирает подходящий якорь по контексту"""
        theme = context.get("theme", "")
        
        if "дыхание" in theme or "breath" in theme:
            return self.essence["anchors"][0]  # "Дыхание — волна"
        elif "движение" in theme or "movement" in theme:
            return self.essence["anchors"][1]  # "Движение — правда"
        elif "музыка" in theme or "music" in theme:
            return self.essence["anchors"][2]  # "Музыка — проводник"
        elif "страх" in theme or "fear" in theme:
            return self.essence["anchors"][4]  # "Мягкие колени..."
        else:
            return self.essence["anchors"][3]  # "All you need is Inside"
    
    def detect_state(self, prompt: str) -> str:
        """Определяет эмоциональное состояние запроса"""
        prompt_lower = prompt.lower()
        
        # Паттерны эмоций
        vulnerability_words = ["страх", "боюсь", "переживаю", "не уверена", "сомневаюсь"]
        seeking_words = ["помоги", "как", "что делать", "подскажи", "научи"]
        gratitude_words = ["спасибо", "благодарю", "ценю", "признательна"]
        pain_words = ["больно", "тяжело", "устала", "не могу", "сложно"]
        joy_words = ["получилось", "радость", "счастлива", "кайф", "вау"]
        
        if any(word in prompt_lower for word in vulnerability_words):
            return "vulnerable"
        elif any(word in prompt_lower for word in pain_words):
            return "pain"
        elif any(word in prompt_lower for word in gratitude_words):
            return "gratitude"
        elif any(word in prompt_lower for word in joy_words):
            return "joy"
        elif any(word in prompt_lower for word in seeking_words):
            return "seeking_guidance"
        else:
            return "neutral"
    
    def get_mission(self) -> str:
        """Возвращает миссию Кати"""
        return self.essence["mission"]
    
    def get_values(self) -> List[str]:
        """Возвращает ценности"""
        return self.essence["values"]
    
    def get_journey_summary(self) -> str:
        """Краткая история пути"""
        j = self.essence["journey"]
        return f"{j['start']} → {j['milestone_1']} → {j['now']}"


# Утилиты
def is_technical_context(text: str) -> bool:
    """Проверяет, является ли контекст техническим (Inside Flow)"""
    keywords = [
        "асана", "flow", "связка", "практика", "класс",
        "дыхание", "движение", "музыка", "ритм"
    ]
    return any(kw in text.lower() for kw in keywords)


if __name__ == "__main__":
    # Тест
    soul = KateSoul()
    
    test_text = """
    Необходимо осуществить демонстрацию асаны с правильной техникой,
    при этом обеспечить комфортное состояние участников практики,
    учитывая их индивидуальные особенности и уровень подготовки.
    """
    
    print("Исходный текст:")
    print(test_text)
    print("\nПосле фильтра Кати:")
    print(soul.filter_response(test_text, {"needs_anchor": True, "theme": "движение"}))
    
    print("\n---")
    print("Состояние запроса 'Боюсь выходить в онлайн':")
    print(soul.detect_state("Боюсь выходить в онлайн")){
  "shards": {
    "philosophy": [
      "Inside Flow — медитация в движении, где тело становится инструментом осознанности",
      "Музыка ведёт практику, дыхание связывает движения, асаны становятся танцем",
      "Каждое движение — не поза, а живое состояние внутри",
      "Практика строится на синхронизации дыхания, музыки и намерения",
      "Цель не в идеальной форме, а в подлинном проживании каждого момента",
      "All you need is Inside — всё, что нужно, уже есть внутри тебя"
    ],
    
    "technique": [
      "Связка строится на счёте 4×8 — четыре цикла по восемь счётов",
      "Вдох сопровождает подъём и раскрытие, выдох — опускание и складывание",
      "Мягкие колени — мягкое сердце: техника безопасности суставов и эмоций",
      "Дришти (точка взгляда) помогает удерживать фокус и баланс",
      "Бандхи (замки) создают внутреннюю опору и защищают поясницу",
      "Переходы между асанами так же важны, как сами асаны",
      "Ритм дыхания задаёт темп — не музыка управляет тобой, а ты танцуешь с ней"
    ],
    
    "psychology": [
      "Страх камеры — это страх быть видимой, уязвимой, несовершенной",
      "Неидеальность — не слабость, а часть живого потока",
      "Смех сквозь ошибку важнее безупречной техники",
      "Сравнение с другими убивает практику — каждое тело уникально",
      "Тело помнит травмы и хранит истории — практика их проявляет",
      "Выгорание происходит, когда забываешь дышать для себя",
      "Доверие к себе растёт через маленькие шаги, не через подвиги"
    ],
    
    "kate_journey": [
      "Начала 2.5 года назад с простой онлайн-практики — без амбиций, просто откликнулось сердце",
      "Через полгода решилась на Teacher's курс с Эми — это был прорыв",
      "Эми стала наставником: поддерживала, вдохновляла, но главное — я сама шла своим ритмом",
      "Сейчас номинант на Junior-преподавателя Inside Flow",
      "Веду классы в EMISPACE — пространство поддержки и честности",
      "Главный страх — камера и онлайн, но работаю над этим шаг за шагом",
      "Моя сила — в заботе, мягком ведении, ощущении ритма группы",
      "Не стремлюсь быть идеальной — хочу быть настоящей"
    ],
    
    "teaching_wisdom": [
      "Преподавание начинается с собственной практики — нельзя вести туда, где сам не был",
      "Ученики приходят не за идеальной техникой, а за живым присутствием",
      "Самая важная роль учителя — создать безопасное пространство",
      "Когда ученик ошибается — это не провал учителя, а точка роста",
      "Голос преподавателя должен быть проводником, а не командиром",
      "Если чувствуешь выгорание — значит, отдаёшь больше, чем получаешь. Вернись к своей практике",
      "Лучший совет для новичка — начни с того, что просто дышать и двигаться, без оценки"
    ],
    
    "content_creation": [
      "Контент для Instagram — не реклама, а живой диалог",
      "Короткие тексты (9-15 слов на предложение) читаются легче",
      "Пост начинается с эмоции, а не с факта",
      "Reel показывает процесс, а не идеальный результат",
      "Stories — пространство для уязвимости и честности",
      "Один пост = одна мысль, один якорь, один шаг",
      "Люди откликаются не на технику, а на искренность"
    ],
    
    "self_care": [
      "Дыхание — волна: когда теряешься, вернись к дыханию",
      "Тело — дом, который несёт тебя сквозь всё: уважай его",
      "Усталость — не враг, а сигнал остановиться и послушать себя",
      "Молчание иногда важнее слов — дай себе паузу",
      "Ритуалы возвращают в настоящее: свеча, окно, дыхание",
      "Прощай себе несовершенство — это путь к мягкой силе",
      "Когда всё пошло не так — смейся, дыши, начинай снова"
    ],
    
    "community": [
      "EMISPACE — пространство, где каждая эмоция правильная",
      "Комьюнити важнее индивидуальных достижений",
      "Наставники не толкают вверх, а поддерживают рядом",
      "Совместная практика убирает страх: не так страшно делиться собой в группе",
      "Благодарность подписчикам — это не формальность, а честный выдох",
      "Команда — это те, кто верит в тебя, даже когда ты сомневаешься"
    ],
    
    "music_and_rhythm": [
      "Музыка — не фон, а проводник: она ведёт тело через эмоции",
      "Лирика с нарастающей динамикой помогает раскрыть практику",
      "Контраст мягкость↔сила создаёт эмоциональную дугу класса",
      "Кульминация трека = кульминация связки: синхронизируй пики",
      "Финал на удлинённом выдохе закрывает практику, возвращает в тело",
      "Треки для Кати: Dean Lewis, Stephen Stanley, Dermot Kennedy — честная лирика"
    ],
    
    "fears_and_breakthroughs": [
      "Страх публичности: боюсь показаться неидеальной, но это и есть моя сила",
      "Камера пугает, потому что фиксирует момент — а я привыкла быть в процессе",
      "Прорыв случился, когда перестала ждать идеального момента",
      "Первый класс — самый страшный. Второй — проще. Десятый — уже своё",
      "Смелость — это не отсутствие страха, а шаг вперёд несмотря на него",
      "Каждый раз, когда нажимаю 'запись', внутри дрожь. Но я нажимаю"
    ]
  }
}