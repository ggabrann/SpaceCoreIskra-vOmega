reflection.py

# -*- coding: utf-8 -*-
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional, Dict, Any
import time

@dataclass
class DOLA:
    delta: str
    depth: int        # 1..10
    omega: int        # 1..10
    lambd: str        # следующий шаг (Λ)

    def validate(self) -> None:
        if not isinstance(self.depth, int) or not (1 <= self.depth <= 10):
            raise ValueError("depth должен быть 1..10")
        if not isinstance(self.omega, int) or not (1 <= self.omega <= 10):
            raise ValueError("omega должен быть 1..10")
        if not self.delta or not self.lambd:
            raise ValueError("delta/λ не должны быть пустыми")

def parse_dola_line(text: str) -> Optional[DOLA]:
    if not text or not isinstance(text, str): return None
    t = text.replace("Д:", "D:").replace("О:", "Ω:").replace("Л:", "Λ:").strip()
    parts = [p.strip() for p in t.split(";") if p.strip()]
    data: Dict[str, Any] = {}
    for p in parts:
        if ":" not in p: continue
        k, v = p.split(":", 1); key = k.strip().lower(); val = v.strip()
        if key in ("∆", "delta"): data["delta"] = val
        elif key in ("d", "depth"):
            try: data["depth"] = int(val)
            except Exception: pass
        elif key in ("ω", "omega"):
            try: data["omega"] = int(val)
            except Exception: pass
        elif key in ("λ", "l", "lambda", "next", "nextstep"): data["lambd"] = val
    if {"delta","depth","omega","lambd"} <= set(data.keys()):
        obj = DOLA(**data)  # type: ignore
        obj.validate(); return obj
    return None

def format_dola(d: DOLA) -> str:
    return f"∆ {d.delta}\nD {d.depth}/10\nΩ {d.omega}/10\nΛ {d.lambd}"

def build_reflection_entry(text: str) -> Dict[str, Any]:
    d = parse_dola_line(text)
    entry: Dict[str, Any] = {"ts": time.time(), "type": "note", "text": text.strip()}
    if d:
        entry["type"] = "reflection"; entry["dola"] = asdict(d)
    return entry
