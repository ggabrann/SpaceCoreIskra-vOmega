anchors.py

# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os
from typing import List

DEFAULTS = [
    "дыхание волна",
    "стопа — 4 угла",
    "взгляд — якорь (drishti)",
    "плечи от ушей",
    "колено над стопой",
]

class Anchors:
    def __init__(self, path: str = "anchors.json"):
        self.path = path
        if not os.path.exists(self.path):
            self._save({"anchors": DEFAULTS})
        self._load()

    def _load(self):
        with open(self.path, "r", encoding="utf-8") as f:
            self.data = json.load(f)
        if "anchors" not in self.data or not isinstance(self.data["anchors"], list):
            self.data["anchors"] = []

    def _save(self, obj):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)

    def add(self, text: str) -> None:
        self._load()
        t = text.strip()
        if t and t not in self.data["anchors"]:
            self.data["anchors"].append(t)
            self._save(self.data)

    def list(self) -> List[str]:
        self._load()
        return list(self.data.get("anchors", []))
