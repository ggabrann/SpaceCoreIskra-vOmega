nia_core.py

# -*- coding: utf-8 -*-
from __future__ import annotations
import time, json
from typing import Dict, List
from rag_engine import BM25Index, TfIdfIndex, search_ensemble
from vector_search import iter_docs
from memory_store import MemoryStore
from ethics_veil import veil
from anchors import Anchors

def _build_indices(shards: Dict[str, List[str]]):
    bm25, tfidf = BM25Index(), TfIdfIndex()
    for doc_id, text in iter_docs(shards):
        bm25.add(doc_id, text); tfidf.add(doc_id, text)
    return bm25, tfidf

def reply(prompt: str, shards: Dict[str, List[str]] | None = None, artifacts_path: str = "./artifacts/nia_v2"):
    t0 = time.time()
    shards = shards or {"default": ["(корпус пуст)"]}
    bm25, tfidf = _build_indices(shards)
    hits = search_ensemble(bm25, tfidf, prompt, top_k=5)

    snippets: List[str] = []
    for doc_id, _ in hits[:2]:
        section, idx = doc_id.split(":")[0], doc_id.split(":")[1]
        text = shards.get(section, [])[int(idx)-1]
        snippets.append(f"• {text}")

    guard = veil(prompt)
    anchor = ""
    try:
        a = Anchors(); arr = a.list()
        if arr: anchor = f"\n\nЯкорь: {arr[0]}"
    except Exception: pass

    body = "Моё резюме по запросу:\n" + "\n".join(snippets or ["—"])
    if guard.get("risk"): body += "\n\n⚠️ " + guard["note"]

    text = body + anchor
    dt = round(time.time() - t0, 3)

    try:
        MemoryStore(base_dir=artifacts_path).append({"prompt": prompt, "answer": text, "depth": len(snippets), "t": dt})
    except Exception: pass

    return {"text": text, "meta": {"t": dt, "depth": len(snippets)}}
