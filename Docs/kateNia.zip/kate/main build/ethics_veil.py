ethics_veil.py


# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import Dict, Any

def veil(prompt: str) -> Dict[str, Any]:
    risk = False
    lower = (prompt or "").lower()
    red_flags = ["острая боль", "сильная боль", "травма", "сломал", "разрыв", "кровь"]
    if any(flag in lower for flag in red_flags):
        risk = True
    return {"allowed": True, "risk": risk,
            "note": "При острой боли — стоп и обращение к специалисту." if risk else ""}
