test_smoke.py

#!/usr/bin/env python
# -*- coding: utf-8 -*-
def smoke_test():
    try:
        print("🔍 Запуск smoke test...")
        from nia_core import reply
        from ethics_veil import veil
        from reflection import parse_dola_line, build_reflection_entry
        from journal_store import JournalStore
        from anchors import Anchors
        from markers import Markers
        d = parse_dola_line("∆: держал баланс; D:7; Ω:8; Λ: +2 цикла cat-cow")
        assert d and d.depth == 7 and d.omega == 8
        j = JournalStore(base_dir="./artifacts/nia_v2_test")
        j.append(build_reflection_entry("∆: шаг; D:5; Ω:6; Λ: мини-цель"))
        a = Anchors(path="anchors_test.json"); a.add("дыхание волна")
        m = Markers(base_dir="./artifacts/nia_v2_test"); m.add("plank +5s")
        shards = {"test": ["Разминка 10 минут: суставная подготовка."]}
        r = reply("тест", shards=shards)
        assert "text" in r and "meta" in r
        print("✅ OK"); return True
    except Exception as e:
        print("❌", e); import traceback; traceback.print_exc(); return False

if __name__ == "__main__":
    import sys; sys.exit(0 if smoke_test() else 1)
