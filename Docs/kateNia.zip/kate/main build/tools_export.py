tools_export.py

# -*- coding: utf-8 -*-
import argparse, glob, zipfile

def make_zip(patterns: str, name: str = "nia_v21_release.zip"):
    pats = [p.strip() for p in patterns.split(",") if p.strip()]
    files = set()
    for p in pats:
        files.update(glob.glob(p, recursive=True))
    with zipfile.ZipFile(name, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(files):
            z.write(f, arcname=f)
    return name

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--patterns", type=str, default="*.py,*.md,*.json")
    ap.add_argument("--name", type=str, default="nia_v21_release.zip")
    args = ap.parse_args()
    out = make_zip(args.patterns, args.name); print(out)

if __name__ == "__main__":
    main()
