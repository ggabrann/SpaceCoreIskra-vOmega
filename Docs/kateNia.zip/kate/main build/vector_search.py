vector_search.py

# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import Dict, List, Iterable, Tuple

def iter_docs(shards: Dict[str, List[str]]) -> Iterable[Tuple[str, str]]:
    for section, arr in (shards or {}).items():
        if not isinstance(arr, list): 
            continue
        for i, text in enumerate(arr):
            doc_id = f"{section}:{i+1}"
            yield doc_id, str(text)
