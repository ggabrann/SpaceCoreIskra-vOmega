markers.py

# -*- coding: utf-8 -*-
from __future__ import annotations
import time, os, json
from typing import Dict, Any, List

class Markers:
    def __init__(self, base_dir: str = "./artifacts/nia_v2", name: str = "markers.jsonl"):
        self.base_dir = base_dir
        os.makedirs(self.base_dir, exist_ok=True)
        self.path = os.path.join(self.base_dir, name)

    def add(self, text: str, tags: List[str] | None = None) -> Dict[str, Any]:
        rec = {"ts": time.time(), "tags": list(tags or ["marker"]), "text": text.strip()}
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return rec

    def tail(self, n: int = 20) -> List[Dict[str, Any]]:
        if not os.path.exists(self.path): return []
        with open(self.path, "r", encoding="utf-8") as f:
            lines = f.readlines()[-n:]
        out = []
        for ln in lines:
            try: out.append(json.loads(ln))
            except Exception: pass
        return out
