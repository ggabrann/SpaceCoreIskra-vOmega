README.md

# NIA v2.1 — Танцующая Нить (InsideFlow Edition)

Минималистичный офлайн-пакет без внешних зависимостей:
- CLI `cli.py`
- Локальный поиск (TF-IDF + BM25)
- Память JSONL
- Рефлексия ∆DΩΛ, дневник JSONL, якоря, маркеры

## Быстрый старт
```bash
cd nia_v21
python test_smoke.py
python cli.py
python cli.py --say "привет"
python cli.py --find "баланс"

Рефлексия и дневник (примеры)

python cli.py --reflect "∆: баланс 20с; D:7; Ω:8; Λ: +2 цикла cat-cow"
python cli.py --journal-add "тихая сессия, дыхание ровное"
python cli.py --journal-tail 5
python cli.py --anchor-add "взгляд — якорь (drishti)"
python cli.py --anchor-list
python cli.py --mark "plank +5s"

Примечания

Журналы и память — формат JSON Lines (строка = JSON-объект).

Корпус лежит в shards_starter.json — расширяй по мере необходимости.

