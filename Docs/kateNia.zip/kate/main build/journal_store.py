journal_store

# -*- coding: utf-8 -*-
from __future__ import annotations
import os, json, time
from typing import Dict, Any, List, Optional

class JournalStore:
    def __init__(self, base_dir: str = "./artifacts/nia_v2", name: str = "journal.jsonl"):
        self.base_dir = base_dir
        os.makedirs(self.base_dir, exist_ok=True)
        self.path = os.path.join(self.base_dir, name)

    def append(self, obj: Dict[str, Any]) -> None:
        o = dict(obj or {}); o.setdefault("ts", time.time())
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(o, ensure_ascii=False) + "\n")

    def tail(self, n: int = 20) -> List[Dict[str, Any]]:
        if not os.path.exists(self.path): return []
        with open(self.path, "r", encoding="utf-8") as f:
            lines = f.readlines()[-n:]
        out = []
        for ln in lines:
            try: out.append(json.loads(ln))
            except Exception: pass
        return out

    def rotate(self, max_lines: int = 10000, keep_last: int = 1000) -> Optional[str]:
        if not os.path.exists(self.path): return None
        with open(self.path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        if len(lines) <= max_lines: return None
        archive = self.path.replace(".jsonl", f"_archive_{int(time.time())}.jsonl")
        os.rename(self.path, archive)
        with open(self.path, "w", encoding="utf-8") as f:
            f.writelines(lines[-keep_last:])
        return archive
