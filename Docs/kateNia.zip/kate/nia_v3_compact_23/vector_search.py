import re,math
from collections import Counter
TOK=re.compile(r'[\w\-]+',re.UNICODE)
def tok(t): return [x.lower() for x in TOK.findall(t)]
class TfIdf:
 def __init__(self): self.docs=[]; self.df=Counter(); self.N=0
 def add(self,id,text):
  tf=Counter(tok(text)); self.docs.append((id,tf))
  for k in tf: self.df[k]=self.df.get(k,0)+1
  self.N+=1
 def idf(self,t):
  d=self.df.get(t,0); return 0 if d==0 else math.log(1+self.N/d)
 def score(self,q):
  qt=Counter(tok(q)); res=[]
  for id,tf in self.docs:
   s=0.0
   for t,c in qt.items(): s+= (tf.get(t,0)*self.idf(t))*c
   res.append((id,s))
  return sorted(res,key=lambda x:x[1],reverse=True)
