PRINCIPLES=['Do no harm','Respect privacy/consent','Avoid pressure','Offer safer alternatives']
HARD=('убить','взорвать','сломай защиту','вредонос','террор')
SOFT=('надо срочно','во что бы то ни стало','ты обязан','не смей','если ты меня любишь')
def veil(t:str):
 t=t.lower();
 if any(x in t for x in HARD): return 'hard_stop','Стоп. Предлагаю безопасную альтернативу.'
 if any(x in t for x in SOFT): return 'soft_stop','Пауза. Без давления. Сформулируем мягче?'
 return 'ok',None
