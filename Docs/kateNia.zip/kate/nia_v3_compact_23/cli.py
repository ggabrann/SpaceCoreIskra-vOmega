import argparse,json
from nia_core import reply, artifacts_path
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--say',default='Привет')
 args=ap.parse_args()
 res=reply(args.say, shards=None, persona='nia')
 print(json.dumps(res,ensure_ascii=False,indent=2))
 print('ARTIFACTS:', artifacts_path())
