# Ния — compact v3 (23 files, flat)
- Полный функционал без папок. Две ячейки для Кати: `Katya_1.md`, `Katya_2.md`.
- Путь к артефактам задаётся в `CONFIG.json` → `artifacts_path`.
