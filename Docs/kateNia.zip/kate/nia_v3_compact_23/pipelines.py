from collections import Counter
import re
def summarize(texts):
 toks=re.findall(r'[\wЁёА-Яа-я]+',' '.join(texts).lower());
 return [w for w,_ in Counter(toks).most_common(50)]
