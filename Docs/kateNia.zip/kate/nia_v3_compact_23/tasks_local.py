import json,uuid
class Tasks:
 def __init__(self,p='tasks.json'): self.p=p; self.t=[]
 def add(self,title,due=None):
  x={'id':str(uuid.uuid4()),'title':title,'due':due,'done':False}; self.t.append(x)
  open(self.p,'w',encoding='utf-8').write(json.dumps(self.t,ensure_ascii=False,indent=2)); return x
