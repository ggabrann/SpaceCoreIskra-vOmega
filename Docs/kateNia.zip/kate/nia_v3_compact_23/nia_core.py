import json
from ethics_veil import veil
from presets_router import route
from persona_module import PERSONAS
from rag_rosette import index as r_index, search as r_search
from pattern_extractor import extract as p_extract
from paradox_resolver import resolve as p_resolve
from memory_store import write_short

def reply(user_text:str, shards:dict[str,list[str]]|None=None, persona='nia')->dict:
 act,msg=veil(user_text)
 if act!='ok': return {'action':act,'message':msg}
 plan=route(user_text); ctx=[]
 if shards: ctx=r_search(r_index(shards), user_text, top_k=5)
 motifs=p_extract(user_text); paradox=p_resolve(user_text)
 tone=PERSONAS.get(persona,PERSONAS['nia'])['tone']
 out=f'[{tone}] План: {plan}. Совпадений: {len(ctx)}.'
 if motifs['count']: out+=f" Мотивы: {', '.join(motifs['motifs'][:3])}."
 if paradox['paradox']: out+=f" Парадокс: {paradox['classes']}."
 write_short(user_text,['input'])
 return {'action':'ok','message':out,'plan':plan,'ctx':ctx,'motifs':motifs,'paradox':paradox}

def artifacts_path():
 try:
  with open('CONFIG.json','r',encoding='utf-8') as f:
   return json.load(f).get('artifacts_path','./artifacts/nia')
 except Exception:
  return './artifacts/nia'
