import json,datetime,os

def append(path:str,obj:dict):
 with open(path,'a',encoding='utf-8') as f: f.write(json.dumps(obj,ensure_ascii=False)+'\n')

def write_short(text:str,tags=None,path='short_term.jsonl'):
 os.makedirs('.',exist_ok=True)
 append(path,{'ts':datetime.datetime.utcnow().isoformat(),'text':text,'tags':tags or []})
