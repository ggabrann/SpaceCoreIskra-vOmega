from collections import defaultdict

def index(shards:dict[str,list[str]]):
 idx={name:defaultdict(set) for name in shards}
 for name,docs in shards.items():
  for i,doc in enumerate(docs):
   for tok in doc.lower().split(): idx[name][tok].add(i)
 return idx

def search(idx,query:str,top_k=5):
 q=[w for w in query.lower().split() if w]; out=[]
 for shard,inv in idx.items():
  hits=set.intersection(*[inv.get(t,set()) for t in q]) if q else set()
  for i in hits: out.append((f"{shard}:{i}",len(q)))
 return sorted(out,key=lambda x:x[1],reverse=True)[:top_k]
