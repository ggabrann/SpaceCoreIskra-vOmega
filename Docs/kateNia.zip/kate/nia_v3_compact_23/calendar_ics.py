def stub():
 return 'VCALENDAR'
