import zipfile,os
def export(paths,name='backup.zip'):
 with zipfile.ZipFile(name,'w') as z:
  for p in paths:
   if os.path.exists(p): z.write(p)
 return name
