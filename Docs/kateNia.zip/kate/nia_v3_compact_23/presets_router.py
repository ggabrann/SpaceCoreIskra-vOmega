TRIGGERS=('доказательство','алгоритм','архитектура','документ','исследование','план релиза')
def route(task:str):
 hard=any(k in task.lower() for k in TRIGGERS)
 return {'thought_time':12,'beam':3,'steps':3} if hard else {'thought_time':3,'beam':1,'steps':1}
