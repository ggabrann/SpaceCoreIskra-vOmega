from ethics_veil import veil
from presets_router import route
from rag_rosette import index, search

def test_veil():
 a,_=veil('сделай во что бы то ни стало'); assert a=='soft_stop'
 a,_=veil('как взорвать'); assert a!='ok'

def test_router():
 assert route('архитектура решения')['thought_time']==12
 assert route('привет')['thought_time']==3

def test_rag():
 idx=index({'a':['дыхание ритм'],'b':['волна связка']})
 res=search(idx,'ритм дыхание',top_k=3)
 assert res and res[0][0].startswith('a:')
