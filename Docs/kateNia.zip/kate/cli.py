# -*- coding: utf-8 -*-
"""
CLI для NIA v2.1 — интерактивный режим + командная строка
"""
from __future__ import annotations
import argparse, json, os, sys
from typing import Dict, List

def load_json(path: str):
    """Загрузка JSON с обработкой ошибок"""
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"⚠️  Ошибка загрузки {path}: {e}")
        return None

def do_find(query: str, shards: Dict[str, List[str]], top_k: int = 8):
    """Поиск по корпусу"""
    from rag_engine import BM25Index, TfIdfIndex, search_ensemble
    from vector_search import iter_docs
    
    bm25, tfidf = BM25Index(), TfIdfIndex()
    
    for doc_id, text in iter_docs(shards):
        bm25.add(doc_id, text)
        tfidf.add(doc_id, text)
    
    return search_ensemble(bm25, tfidf, query, top_k=top_k)

def interactive_mode(shards_path: str = "shards_starter.json", artifacts_path: str = "."):
    """Интерактивное меню для нетехнических пользователей"""
    from nia_core import reply
    from memory_store import MemoryStore
    
    shards = load_json(shards_path)
    
    if not shards:
        print("⚠️  Корпус не найден.")
        print("Создайте shards_starter.json или укажите путь через --shards")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("НИЯ v2.1 — Танцующая Нить (InsideFlow Edition)")
    print("="*60)
    print(f"Корпус загружен: {sum(len(v) for v in shards.values())} документов")
    print()
    
    while True:
        print("\nМЕНЮ:")
        print("1) Задать вопрос Ние")
        print("2) Найти в корпусе")
        print("3) Последние записи памяти")
        print("4) Выход")
        
        choice = input("\nВыбери (1-4): ").strip()
        
        if choice == "1":
            q = input("\nТвой запрос: ").strip()
            if not q:
                print("⚠️  Запрос пустой")
                continue
            
            print("\n⏳ Обрабатываю...\n")
            result = reply(q, shards=shards, artifacts_path=artifacts_path)
            
            print(result["text"])
            print(f"\n[Время: {result['meta']['t']}s | Глубина: {result['meta'].get('depth', 'N/A')}]")
        
        elif choice == "2":
            q = input("\nЧто искать: ").strip()
            if not q:
                print("⚠️  Запрос пустой")
                continue
            
            hits = do_find(q, shards, top_k=10)
            print(f"\n✓ Найдено {len(hits)} фрагментов:\n")
            
            for i, (doc_id, score) in enumerate(hits, 1):
                print(f"{i}. {doc_id} — {score:.3f}")
        
        elif choice == "3":
            try:
                mem = MemoryStore(base_dir=artifacts_path)
                records = mem.tail(10)
                
                if not records:
                    print("\n⚠️  Память пуста")
                else:
                    print(f"\n✓ Последние {len(records)} записей:\n")
                    for r in records:
                        ts = r.get('ts', 0)
                        prompt = r.get('prompt', 'N/A')[:60]
                        print(f"• {prompt}... (depth={r.get('depth', 'N/A')})")
            except Exception as e:
                print(f"⚠️  Ошибка чтения памяти: {e}")
        
        elif choice == "4":
            print("\nПока! ☉")
            break
        
        else:
            print("⚠️  Неверный выбор")

def main():
    """Главная функция CLI"""
    ap = argparse.ArgumentParser(description="NIA v2.1 CLI")
    
    ap.add_argument("--say", type=str, help="Запрос к Ние")
    ap.add_argument("--find", type=str, help="Поиск по корпусу")
    ap.add_argument("--memory", type=int, help="Последние N записей памяти")
    ap.add_argument("--shards", type=str, default="shards_starter.json", help="Путь к корпусу JSON")
    ap.add_argument("--artifacts", type=str, default=".", help="Путь для JSONL-памяти")
    ap.add_argument("--topk", type=int, default=8, help="Количество результатов поиска")
    
    args = ap.parse_args()
    
    # Режим --say
    if args.say:
        from nia_core import reply
        
        shards = load_json(args.shards)
        result = reply(args.say, shards=shards, artifacts_path=args.artifacts)
        
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    # Режим --find
    if args.find:
        shards = load_json(args.shards)
        if not shards:
            print("⚠️  Корпус не найден")
            sys.exit(1)
        
        hits = do_find(args.find, shards, top_k=args.topk)
        print(json.dumps(hits, ensure_ascii=False, indent=2))
        return
    
    # Режим --memory
    if args.memory:
        from memory_store import MemoryStore
        
        mem = MemoryStore(base_dir=args.artifacts)
        records = mem.tail(args.memory)
        
        print(json.dumps(records, ensure_ascii=False, indent=2))
        return
    
    # Интерактивный режим (по умолчанию)
    interactive_mode(args.shards, args.artifacts)

if __name__ == "__main__":
    main()
