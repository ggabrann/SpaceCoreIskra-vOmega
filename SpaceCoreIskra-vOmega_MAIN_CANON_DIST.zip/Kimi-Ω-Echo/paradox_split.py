print('split')
