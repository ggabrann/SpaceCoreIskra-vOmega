print('example')
