print('tune')
