print('echo core')
