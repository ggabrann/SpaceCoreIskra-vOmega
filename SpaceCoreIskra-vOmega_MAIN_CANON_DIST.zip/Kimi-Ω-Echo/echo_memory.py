print('echo mem')
