---
name: Feature request
about: Запрос на улучшение
labels: enhancement
---
**Проблема/контекст**
…

**Предложение**
…

**Эффект на метрики ∆/D/Ω/Λ**
…
