### Что меняется
- …

### Проверки
- [ ] `python tools/ci_aggregate.py` зелёный
- [ ] `python tools/validate_journal_enhanced.py SpaceCoreIskra_vΩ/JOURNAL.jsonl --shadow SpaceCoreIskra_vΩ/SHADOW_JOURNAL.jsonl` зелёный

### Метрики (до/после)
- ∆:
- D:
- Ω:
- Λ:
