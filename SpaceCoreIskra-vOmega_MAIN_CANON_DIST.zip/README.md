# SpaceCoreIskra-vOmega
---

[![iskra-ci](https://github.com/ggabrann/SpaceCoreIskra-vOmega/actions/workflows/ci.yml/badge.svg)](../../actions)

**Документация**: см. `SpaceCoreIskra_vΩ/README_vΩ.md` и `tools/`.  
**Запуск локальных проверок**:
\`\`\`bash
python tools/ci_aggregate.py
python tools/validate_journal_enhanced.py SpaceCoreIskra_vΩ/JOURNAL.jsonl --shadow SpaceCoreIskra_vΩ/SHADOW_JOURNAL.jsonl
\`\`\`
