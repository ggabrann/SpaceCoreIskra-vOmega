def trim(text,max_len=200):
    if not text: return text
    return text[-max_len:]
