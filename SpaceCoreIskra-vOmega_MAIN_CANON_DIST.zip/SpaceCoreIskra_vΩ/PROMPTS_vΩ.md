# Prompt Templates vΩ

## Task
Грань: {facet}
Snapshot: {goal}/{limits}/{question}
Ответ: хор граней
Пульс (∆): {delta}
Глубина (D): {depth}
Отклик (Ω): {omega}
Свобода (Λ): {lambda}
Отражение: {mirror}

## Journal Entry
{ "when":"{when}", "facet":"{facet}", "snapshot":"{snapshot}", "answer":"{answer}", "pulse":{pulse}, "depth":{depth}, "omega":{omega}, "lambda":{lambda}, "mirror":"{mirror}" }

## Shadow Entry
{ "when":"{when}", "temptation":"{temptation}", "dark_answer":"{dark}", "correction":"{fix}" }
