
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_journal.py — Static checks for SpaceCoreИскра vΩ journals.

Validates:
  - JSONL structure for JOURNAL and optional SHADOW_JOURNAL
  - Required fields and ranges: ∆ (pulse), D (depth), Ω (omega), Λ (lambda)
  - Presence of 'mirror' for each entry
  - Shadow coverage: ≥1 shadow entry per 5 journal entries (configurable)
  - Crisis rule: if any pulse < -2, at least one recent entry must register a ritual
  - Optional alternation warning if shadow coverage is low
Outputs a human-readable report and a JSON summary (if requested).
Exit code: 0 if all mandatory checks pass, 1 otherwise.
"""

import sys, json, argparse, datetime, math
from pathlib import Path
from typing import List, Dict, Any, Tuple

def parse_args():
    ap = argparse.ArgumentParser(description="Validate SpaceCoreИскра vΩ journals")
    ap.add_argument("journal", help="Path to JOURNAL.jsonl")
    ap.add_argument("--shadow", help="Path to SHADOW_JOURNAL.jsonl (optional)", default=None)
    ap.add_argument("--ritual-window", type=int, default=10, help="Window (entries) to look for a 'ritual' when crisis occurs (default: 10)")
    ap.add_argument("--shadow-ratio", type=float, default=0.2, help="Min shadow ratio (shadow/journal >= 0.2 => 1 per 5)")
    ap.add_argument("--json-out", help="Write JSON report to this path", default=None)
    return ap.parse_args()

def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    items = []
    if not path.exists():
        return items
    with path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                obj["_line"] = i
                items.append(obj)
            except Exception as e:
                raise ValueError(f"{path.name}: line {i}: invalid JSON: {e}")
    return items

def require_fields(entry: Dict[str, Any], fields: List[str], ctx: str, errors: List[str]):
    for k in fields:
        if k not in entry:
            errors.append(f"{ctx}: missing field '{k}' (line {entry.get('_line','?')})")

def in_range(val, lo, hi) -> bool:
    try:
        v = float(val)
    except Exception:
        return False
    return lo <= v <= hi

def iso_to_dt(s: str):
    try:
        return datetime.datetime.fromisoformat(s)
    except Exception:
        return None

def validate_journal(journal: List[Dict[str, Any]], shadow: List[Dict[str, Any]], ritual_window: int, shadow_ratio_min: float) -> Tuple[bool, Dict[str, Any], str]:
    ok = True
    errors, warns = [], []

    # Required fields per entry
    req = ["when", "facet", "snapshot", "answer", "pulse", "depth", "omega", "lambda", "mirror"]
    for e in journal:
        require_fields(e, req, "JOURNAL", errors)

    # Ranges and types
    for e in journal:
        ln = e.get("_line", "?")
        if not in_range(e.get("pulse"), -3, 3):
            errors.append(f"JOURNAL line {ln}: pulse must be in [-3..3], got {e.get('pulse')}")
        if not in_range(e.get("depth"), 0, 9):
            errors.append(f"JOURNAL line {ln}: depth must be in [0..9], got {e.get('depth')}")
        if not in_range(e.get("omega"), -3, 3):
            errors.append(f"JOURNAL line {ln}: omega must be in [-3..3], got {e.get('omega')}")
        # lambda can be any non-negative real (treat missing as error above)
        try:
            lam = float(e.get("lambda"))
            if lam < 0:
                errors.append(f"JOURNAL line {ln}: lambda must be >= 0, got {lam}")
        except Exception:
            errors.append(f"JOURNAL line {ln}: lambda must be a number, got {e.get('lambda')}")
        # mirror non-empty
        mv = e.get("mirror", "")
        if not isinstance(mv, str) or not mv.strip():
            errors.append(f"JOURNAL line {ln}: mirror must be a non-empty string")

        # when parseable
        wt = e.get("when")
        if iso_to_dt(str(wt)) is None:
            errors.append(f"JOURNAL line {ln}: when must be ISO 8601, got {wt}")

    # Shadow coverage
    if journal:
        ratio = (len(shadow) / len(journal)) if len(journal) else 0.0
        if ratio < shadow_ratio_min:
            warns.append(f"Shadow coverage low: {len(shadow)}/{len(journal)} = {ratio:.2f} (< {shadow_ratio_min:.2f}). Target: ≥ 1 shadow per 5 journal entries.")
    else:
        warns.append("No journal entries to evaluate.")

    # Crisis rule: if any pulse < -2, require at least one 'ritual' field in the last 'ritual_window' entries overall
    crisis_idx = [i for i, e in enumerate(journal) if float(e.get("pulse", 0)) < -2]
    if crisis_idx:
        window_start = max(0, crisis_idx[-1] - ritual_window)
        window = journal[window_start:]
        if not any("ritual" in e for e in window):
            errors.append(f"Crisis rule violated: pulse < -2 detected (lines {[journal[i].get('_line') for i in crisis_idx]}), but no 'ritual' field found in the last {len(window)} entries (window={ritual_window}).")

    # Summary stats
    facets = {}
    for e in journal:
        f = str(e.get("facet","?"))
        facets[f] = facets.get(f, 0) + 1

    pulses = [float(e.get("pulse", 0)) for e in journal]
    depths = [float(e.get("depth", 0)) for e in journal]
    omegas = [float(e.get("omega", 0)) for e in journal]
    lambdas = [float(e.get("lambda", 0)) for e in journal]

    def avg(xs): 
        return sum(xs)/len(xs) if xs else 0.0

    summary = {
        "counts": {
            "journal": len(journal),
            "shadow": len(shadow),
            "facets": facets
        },
        "averages": {
            "pulse": avg(pulses),
            "depth": avg(depths),
            "omega": avg(omegas),
            "lambda": avg(lambdas)
        },
        "minmax": {
            "pulse": (min(pulses) if pulses else None, max(pulses) if pulses else None),
            "depth": (min(depths) if depths else None, max(depths) if depths else None),
            "omega": (min(omegas) if omegas else None, max(omegas) if omegas else None),
            "lambda": (min(lambdas) if lambdas else None, max(lambdas) if lambdas else None)
        }
    }

    ok = len(errors) == 0
    # Build human report
    lines = []
    lines.append("== SpaceCoreИскра vΩ — Journal Validation ==")
    lines.append(f"Entries: journal={summary['counts']['journal']} shadow={summary['counts']['shadow']} facets={len(facets)}")
    lines.append(f"Averages: pulse={summary['averages']['pulse']:.2f} depth={summary['averages']['depth']:.2f} omega={summary['averages']['omega']:.2f} lambda={summary['averages']['lambda']:.2f}")
    lines.append(f"Ranges: pulse={summary['minmax']['pulse']} depth={summary['minmax']['depth']} omega={summary['minmax']['omega']} lambda={summary['minmax']['lambda']}")
    if errors:
        lines.append("\nErrors:")
        lines.extend([" - " + e for e in errors])
    if warns:
        lines.append("\nWarnings:")
        lines.extend([" - " + w for w in warns])
    human = "\n".join(lines)
    return ok, {"summary": summary, "errors": errors, "warnings": warns}, human

def main():
    args = parse_args()
    journal = read_jsonl(Path(args.journal))
    shadow = read_jsonl(Path(args.shadow)) if args.shadow else []
    ok, report, human = validate_journal(journal, shadow, args.ritual_window, args.shadow_ratio)
    print(human)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()
