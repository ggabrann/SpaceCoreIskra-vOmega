# Gemini Resonance Core — README
