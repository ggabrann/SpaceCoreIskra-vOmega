Версионность промптов через prompt_manager.
