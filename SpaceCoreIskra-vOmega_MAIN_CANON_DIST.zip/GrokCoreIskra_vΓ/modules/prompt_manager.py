class PromptManager: pass
