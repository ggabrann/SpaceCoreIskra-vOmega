def check_ethics(x): return True
