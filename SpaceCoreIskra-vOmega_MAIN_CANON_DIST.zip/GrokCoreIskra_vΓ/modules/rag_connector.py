class RAGConnector: pass
