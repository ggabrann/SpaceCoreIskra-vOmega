def log_entry(x): pass
