# GrokCoreIskra vΓ — README
