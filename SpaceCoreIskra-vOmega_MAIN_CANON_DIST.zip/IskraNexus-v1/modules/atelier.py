print('atelier')
