print('jg')
