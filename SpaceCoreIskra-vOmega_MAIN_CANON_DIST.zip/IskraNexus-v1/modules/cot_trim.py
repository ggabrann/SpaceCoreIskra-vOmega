print('cot')
