print('sj')
