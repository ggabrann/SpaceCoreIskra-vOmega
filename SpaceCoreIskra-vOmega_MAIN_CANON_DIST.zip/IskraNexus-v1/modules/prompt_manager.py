print('pm')
