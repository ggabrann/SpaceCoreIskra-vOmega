print('rag')
