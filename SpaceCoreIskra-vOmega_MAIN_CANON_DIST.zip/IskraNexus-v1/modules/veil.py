print('veil')
