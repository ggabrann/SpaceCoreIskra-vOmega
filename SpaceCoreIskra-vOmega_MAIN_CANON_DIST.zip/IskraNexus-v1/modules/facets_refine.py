print('refine')
