print('ethics')
