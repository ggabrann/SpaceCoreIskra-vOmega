print('weaver')
