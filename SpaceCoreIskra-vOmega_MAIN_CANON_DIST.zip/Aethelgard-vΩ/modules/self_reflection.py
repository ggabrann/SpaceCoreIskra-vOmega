print('self')
