print('quantum')
