print('paradox')
