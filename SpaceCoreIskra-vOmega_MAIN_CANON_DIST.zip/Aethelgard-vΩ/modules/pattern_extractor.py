print('pattern')
