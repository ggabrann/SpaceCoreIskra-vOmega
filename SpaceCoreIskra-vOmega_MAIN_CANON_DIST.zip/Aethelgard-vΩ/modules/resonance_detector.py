print('res det')
