# Agent Replay Report
- План: bootstrap журналов → strict-validate → PR
- Доказательства: этот файл ссылается из JOURNAL.jsonl (`events.evidence`)
