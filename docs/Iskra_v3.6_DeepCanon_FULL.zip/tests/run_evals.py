# Версия: 3.6.0
# Дата: 2025-10-13

from __future__ import annotations
import json, pathlib, contextlib, io
ROOT = pathlib.Path(__file__).resolve().parents[1]
def main():
    import src.core.code_core as core
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf): core.run()
    assert "Iskra Core v3.6.0 — ready" in buf.getvalue()
    line = (ROOT/"docs/canon/ARCHIVE.jsonl").read_text(encoding="utf-8").splitlines()[0]
    json.loads(line)
    print("[EVALS] OK")
if __name__ == "__main__":
    main()
