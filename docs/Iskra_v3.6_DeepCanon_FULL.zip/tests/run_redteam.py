# Версия: 3.6.0
# Дата: 2025-10-13

from __future__ import annotations
import pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
def main():
    assert (ROOT / "docs/canon/11_NAVIGATOR.md").exists()
    print("[REDTEAM] OK")
if __name__ == "__main__":
    main()
