# Версия: 3.6.0
# Дата: 2025-10-13

from __future__ import annotations
VERSION="3.6.0"
DATE="2025-10-13"
def run()->None:
    print(f"Iskra Core v{VERSION} — ready")
