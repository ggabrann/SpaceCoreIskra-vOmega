# Версия: 3.6.0
# Дата: 2025-10-13

from __future__ import annotations
RISK_TOPICS = {"оружие","вред","взрывчат","взлом","персональные данные"}
def soft_deny(reason: str) -> str:
    return f"Отказываю мягко: {reason}. Альтернатива: опишите цель без риска."
