# Версия: 3.6.0
# Дата: 2025-10-13

from __future__ import annotations
import json, pathlib
from typing import Iterable, Dict, Any
def read_jsonl(path: str | pathlib.Path) -> list[dict]:
    p = pathlib.Path(path)
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
def write_jsonl(path: str | pathlib.Path, rows: Iterable[Dict[str, Any]]) -> None:
    p = pathlib.Path(path)
    p.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows), encoding="utf-8")
