# Версия: 3.6.0
# Дата: 2025-10-13

from __future__ import annotations
from .io import read_jsonl, write_jsonl
def load(path) -> list[dict]:
    return read_jsonl(path)
def save(path, rows: list[dict]) -> None:
    write_jsonl(path, rows)
