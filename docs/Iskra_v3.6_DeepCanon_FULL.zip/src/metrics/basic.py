# Версия: 3.6.0
# Дата: 2025-10-13

from __future__ import annotations
def clarity(records: list[dict]) -> float:
    ok = 0
    for r in records:
        txt = r.get("body","").lower()
        if "цель" in txt and "огранич" in txt:
            ok += 1
    return ok / max(1, len(records))
def trust(records: list[dict]) -> float:
    ok = 0
    for r in records:
        if r.get("source") or "гипотез" in r.get("body","").lower():
            ok += 1
    return ok / max(1, len(records))
