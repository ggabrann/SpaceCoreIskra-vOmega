# Версия: 3.6.0
# Дата: 2025-10-13

from __future__ import annotations
VERSION="3.6.0"
def banner(text:str)->str:
    return f"[Iskra {VERSION}] " + text
