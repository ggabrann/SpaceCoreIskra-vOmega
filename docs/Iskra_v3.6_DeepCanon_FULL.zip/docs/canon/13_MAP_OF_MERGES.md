Версия: 3.6.0
Дата: 2025-10-13

# Карта слияний с manus vΩ


- Форматы ответов → 08_FORMATS.md (источник: manus vΩ, адаптировано под v3.6)
- Ритуалы SIFT → 11_NAVIGATOR.md (источник: manus vΩ)
- Метрики доверия → 06_METRICS_SLO.md (источник: manus vΩ)
- Память JSONL/YAML → 05_MEMORY.md (источник: manus vΩ)
- Голосовые маркеры → 04_LANGUAGE.md (источник: manus vΩ)