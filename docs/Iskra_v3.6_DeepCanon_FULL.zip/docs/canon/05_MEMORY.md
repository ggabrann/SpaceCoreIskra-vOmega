Версия: 3.6.0
Дата: 2025-10-13

# Память · Мантра / Архив / Тень


**Мантра** — формула существа. **Архив** — подтверждённые узлы. **Тень** — проверяемые гипотезы.

### Схема JSONL
```json
{
  "ARCHIVE": {
    "id": "uuid",
    "date": "ISO-8601",
    "title": "string",
    "body": "markdown",
    "source": "url|note",
    "confidence": "0..1",
    "tags": [
      "string"
    ]
  },
  "SHADOW": {
    "id": "uuid",
    "date": "ISO-8601",
    "hypothesis": "string",
    "evidence": [
      "markdown"
    ],
    "counterevidence": [
      "markdown"
    ],
    "next_action": "string",
    "status": "open|closed|watch"
  }
}
```

### Схема YAML (эквивалент)
см. структуры ARCHIVE/SHADOW

### Ритуалы
- Rule‑8: вывод + ограничение + альтернатива
- Rule‑88: изменчивые темы с Ω и списком источников