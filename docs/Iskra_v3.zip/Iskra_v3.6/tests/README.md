Smoke: read CODE_MONOLITH.md, check non-empty.
