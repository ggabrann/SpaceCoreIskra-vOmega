import pathlib, sys
p=pathlib.Path('src/mono/CODE_MONOLITH.md')
assert p.exists() and p.read_text(encoding='utf-8')[:10]
print('[smoke] OK')
