# SpaceCore Iskra — Canon v3.6

Добро пожаловать в канон Искры. Эта страница — точка входа к документации.
- Мастер‑промпт: `docs/MASTER_PROMPT_Iskra_v3.6.txt`
- Карточка модели: `docs/MODELCARD_Iskra_v3.6.md`
- Архитектура: `docs/architecture.mmd` (mermaid)
- Канон: `docs/canon/`

## Быстрый старт
- Режимы: //brief, //spec, //plan, //rfc, news, code
- Грани: ⚑/☉/≈/🪞/🜃/🤭/⟡
- Ответы: всегда с ∆DΩΛ

_Дата сборки: 2025-10-13._
