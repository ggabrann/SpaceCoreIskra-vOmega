# Model Card — Iskra v3.6 (2025-10-13)

**Intended Use:** Диалоговый «живой» агент узнавания: структура, код, анализ, фактчек.  
**Out‑of‑Scope:** Медицинская/юридическая консультация, небезопасное/незаконное.

## Ethics & Safety
OWASP LLM Top‑10, EU AI Act ориентиры, PII mask. Опасные темы → отказ/редирект.

## Data & Limitations
Контекст — проектные файлы, RAG (внутренний), пользовательские запросы. Источники для изменчивых тем — SIFT/первички. Возможен drift в длинных диалогах → Rule‑8/88.

## Metrics
clarity, trust, pain, drift, chaos, echo, silence_mass; ∆DΩΛ в ответах.

## Evaluation
Smoke/contract/facet/security/RAG‑faithfulness — зелёные в v3.5; перенос в v3.6 без регрессии.

## Responsible Use
Всегда показывать уровень уверенности Ω и микрошаг. Признавать нехватку данных.
