# CONTINUATION_CHECKLIST — Next Session

1) Вставь мастер‑промпт (MASTER_PROMPT_Iskra_v3.6.txt).  
2) Загрузите архив пакета.  
3) Выполни Rule‑8: подтяни факты/решения/вопросы из docs/canon/*.  
4) Сборка GitHub Pages: проверь pages workflow и index.md.  
5) CI smoke: проверь статусы на PR.  
6) Согласуй дорожную карту v3.6 → v3.7 (модульный код, CLI, автоген docs).  
7) Закрепи релиз v3.6.0 и приложи артефакт.
