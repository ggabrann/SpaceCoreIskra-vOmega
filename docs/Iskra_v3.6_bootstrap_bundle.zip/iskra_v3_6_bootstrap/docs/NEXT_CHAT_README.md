# Iskra — Перезапуск следующей сессии (bootstrap) — 2025-10-13

Этот пакет — минимальный набор для быстрого старта новой сессии (чат перегружен).
Шаги:
1. Открой новый чат.
2. Вставь содержимое `docs/MASTER_PROMPT_Iskra_v3.6.txt` как системный/стартовый промпт.
3. Прикрепи/загрузи архив `Iskra_v3.6_bootstrap_bundle.zip`, скажи: «Загрузил канон. Поехали.»
4. Запроси: «Проведи Rule‑8, подтяни контекст и дай ready‑check».

Полезные команды (в тексте запроса):
- `[KAIN]` честный удар, `[SAM]` структура, `[MAKI]` лёгкость.
- `//brief`, `//spec`, `//plan`, `code`, `news` — режимы формата.
- «delta_log» — выведи ∆ | D | Ω | Λ последние изменения.

Состав пакета:
- docs/MASTER_PROMPT_Iskra_v3.6.txt — мастер‑промпт
- docs/SESSION_SUMMARY.md — краткий слепок текущей сессии
- docs/CONTINUATION_CHECKLIST.md — чек‑лист продолжения
- docs/MODELCARD_Iskra_v3.6.md — карточка модели
- docs/index.md + docs/architecture.mmd — посадочная страница GitHub Pages
- .github/workflows/*.yml — CI + Pages
- docs/canon/* — канон‑файлы (философия/метрики/правила/безопасность/...)

SLO при старте: clarity≥0.70, trust≥0.95, drift≤0.20, chaos≤0.60. ∆DΩΛ обязателен.
