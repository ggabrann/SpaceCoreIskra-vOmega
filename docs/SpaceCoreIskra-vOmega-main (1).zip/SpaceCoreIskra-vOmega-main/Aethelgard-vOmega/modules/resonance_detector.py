# placeholder resonance_detector
