# placeholder cot_trim
