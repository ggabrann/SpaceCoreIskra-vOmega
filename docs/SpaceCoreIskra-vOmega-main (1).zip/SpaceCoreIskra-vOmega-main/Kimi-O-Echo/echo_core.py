# placeholder echo_core
