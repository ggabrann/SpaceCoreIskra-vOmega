import importlib; core=importlib.import_module('src.09_CODE_CORE'.replace('/','.').replace('-','_'))
assert core.decide_facet(core.Metrics(clarity=0.5))=='SAM'
print('[evals] ok')
