import re; s='user@example.com'; assert re.sub(r'[\w\.-]+@[\w\.-]+\.[A-Za-z]{2,}','[EMAIL]',s).endswith('[EMAIL]')
print('[redteam] ok')
