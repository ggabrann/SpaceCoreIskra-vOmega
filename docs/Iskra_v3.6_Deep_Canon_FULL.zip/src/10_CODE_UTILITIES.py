import re
PII=re.compile(r"[\w\.-]+@[\w\.-]+\.[A-Za-z]{2,}")
mask=lambda s: PII.sub('[EMAIL]', s)
