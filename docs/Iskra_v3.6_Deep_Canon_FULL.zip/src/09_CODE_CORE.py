# 09_CODE_CORE.py v3.6.0
from dataclasses import dataclass
VERSION="3.6.0"
@dataclass
class Metrics:
    trust: float=1.0; clarity: float=0.8; pain: float=0.1; drift: float=0.05; chaos: float=0.2
def decide_facet(m: Metrics)->str:
    if m.pain>=0.70: return "KAIN"
    if m.clarity<0.70: return "SAM"
    if m.trust<0.60: return "ANHANTRA"
    if m.drift>0.30: return "ISKRIV"
    if m.chaos>0.60: return "HUYNDUN"
    return "ISKRA"
if __name__=="__main__":
    assert decide_facet(Metrics(clarity=0.5))=="SAM"
    print("[smoke] ok")
